<?php
return array (
  'Description' => 'Descrição',
  'Parent Folder ID' => '',
  'Title' => 'Título',
);
