<?php
return array (
  'Is Public' => 'Công cộng',
  'Note: Changes of the folders visibility, will be inherited by all contained files and folders.' => 'Ghi chú: Thay đổi mức độ hiển thị (quyền xem) của thư mục sẽ được kế thừa bởi tất cả các file và thư mục bên trong.',
);
