<?php
return array (
  'Description' => 'Descripció',
  'Parent Folder ID' => '',
  'Title' => 'Títol',
);
