<?php
return array (
  'Description' => '説明',
  'Parent Folder ID' => '',
  'Title' => 'タイトル',
);
