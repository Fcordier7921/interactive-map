<?php
return array (
  'Is Public' => 'Javno',
  'Note: Changes of the folders visibility, will be inherited by all contained files and folders.' => 'Napomena: Promjene vidljivosti mapa nasljeđuju sve sadržane datoteke i mape.',
);
