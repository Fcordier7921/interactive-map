<?php
return array (
  'Is Public' => 'Är publik',
  'Note: Changes of the folders visibility, will be inherited by all contained files and folders.' => 'Not: Ändringar av mapparnas synlighet ärvs av alla filer & mappar.',
);
