<?php
return array (
  'Could not save file %title%. ' => 'Nem sikerült a %title% fájlt menteni.',
);
