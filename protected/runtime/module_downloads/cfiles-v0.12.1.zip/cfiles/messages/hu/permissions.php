<?php
return array (
  'Add files' => 'Fájlok hozzáadása',
  'Allows the user to modify or delete any files.' => 'Lehetővé teszi a felhasználó számára tetszőleges fájl szerkesztését vagy törlését.',
  'Allows the user to upload new files and create folders' => 'Lehetővé teszi a felhasználó számára, hogy új fájlokat töltsön fel és mappákat hozzon létre',
  'Manage files' => 'Fájlok kezelése',
);
