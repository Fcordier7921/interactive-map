<?php
return array (
  'Could not save file %title%. ' => 'Nu am putut salva fisierul %title%.',
);
