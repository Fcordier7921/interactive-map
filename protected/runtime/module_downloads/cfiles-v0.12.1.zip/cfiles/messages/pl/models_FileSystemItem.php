<?php
return array (
  'Is Public' => 'Jest Publiczny',
  'Note: Changes of the folders visibility, will be inherited by all contained files and folders.' => 'Notatka: Zmiany widoczności folderów, będą dziedziczone przez wszystkie zawarte pliki i foldery.',
);
