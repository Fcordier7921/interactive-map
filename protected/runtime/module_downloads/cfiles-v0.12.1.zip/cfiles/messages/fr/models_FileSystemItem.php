<?php
return array (
  'Is Public' => 'est public',
  'Note: Changes of the folders visibility, will be inherited by all contained files and folders.' => 'Note : modifie la visibilité des dossiers, qui va être héritée par tous les fichiers et dossiers qu\'ils contiennent.',
);
