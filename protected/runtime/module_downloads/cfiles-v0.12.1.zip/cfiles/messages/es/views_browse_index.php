<?php
return array (
  'Could not save file %title%. ' => 'No se pudo guardar el archivo %title%.',
);
