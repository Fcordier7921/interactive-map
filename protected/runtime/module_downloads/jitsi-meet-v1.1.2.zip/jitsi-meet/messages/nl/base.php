<?php

return [
    '<strong>Jitsi</strong> module configuration' => '<strong>Jitsi</strong> module configuratie',
    'Close' => 'Sluit',
    'Default is meet.jit.si without "https://" prefix.' => 'Standaard is meet.jit.si zonder voorvoegsel "https: //".',
    'Default: Jitsi Meet' => 'Standaard: Jitsi Meet',
    'Default: empty, useful for public Jitsi server' => 'Standaard: leeg, handig voor openbare Jitsi-server',
    'Invite' => 'uitnodigen',
    'Join' => 'Doe mee',
    'Name' => 'Naam',
    'Open conference room' => 'Open conferentieruimte',
    'Open in new window?' => 'Openen in een nieuw venster?',
    'Application ID shared with a private Jitsi server used to generate JWT token for authentication. Default: empty, no JWT token authentication will be used.' => '',
    'Application secret shared with a private Jitsi server used to sign JWT token for authentication. Default: empty, needed if JWT token should be generated.' => '',
    'Enable JWT Authentication' => '',
];
