<?php

return [
    '<strong>Jitsi</strong> module configuration' => 'Configuração do módulo <strong> Jitsi </strong>',
    'Close' => 'Fechar',
    'Default is meet.jit.si without "https://" prefix.' => 'O padrão é meet.jit.si sem o prefixo "https: //".',
    'Default: Jitsi Meet' => 'Padrão: Jitsi Meet',
    'Default: empty, useful for public Jitsi server' => 'Padrão: vazio, útil para o servidor público Jitsi',
    'Invite' => 'Convite',
    'Join' => 'Junte-se',
    'Name' => 'Nome',
    'Open conference room' => 'Sala de conferências aberta',
    'Open in new window?' => 'Abrir em uma nova janela?',
    'Application ID shared with a private Jitsi server used to generate JWT token for authentication. Default: empty, no JWT token authentication will be used.' => '',
    'Application secret shared with a private Jitsi server used to sign JWT token for authentication. Default: empty, needed if JWT token should be generated.' => '',
    'Enable JWT Authentication' => '',
];
