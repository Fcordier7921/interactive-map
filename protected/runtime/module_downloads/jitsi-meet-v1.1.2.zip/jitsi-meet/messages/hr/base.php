<?php

return [
    'Close' => 'Zatvori',
    'Invite' => 'Poziv',
    'Name' => 'Ime',
    '<strong>Jitsi</strong> module configuration' => '',
    'Application ID shared with a private Jitsi server used to generate JWT token for authentication. Default: empty, no JWT token authentication will be used.' => '',
    'Application secret shared with a private Jitsi server used to sign JWT token for authentication. Default: empty, needed if JWT token should be generated.' => '',
    'Default is meet.jit.si without "https://" prefix.' => '',
    'Default: Jitsi Meet' => '',
    'Default: empty, useful for public Jitsi server' => '',
    'Join' => '',
    'Open conference room' => '',
    'Open in new window?' => '',
    'Enable JWT Authentication' => '',
];
