<?php

return [
    '<strong>Jitsi</strong> module configuration' => 'Konfiguracja modułu <strong>Jitsi</strong>',
    'Close' => 'Zamknij',
    'Default is meet.jit.si without "https://" prefix.' => 'Domyślne to meet.jit.si bez prefixu "https://"',
    'Default: Jitsi Meet' => 'Domyślnie: Jitsi Meet',
    'Default: empty, useful for public Jitsi server' => 'Domyślnie: puste, przydatne dla publicznych serwerów jitsi',
    'Invite' => 'Zaproś',
    'Join' => 'Dołącz',
    'Name' => 'Nazwa',
    'Open conference room' => 'Otwórz pokój konferencji',
    'Open in new window?' => 'Otworzyć w nowym oknie?',
    'Application ID shared with a private Jitsi server used to generate JWT token for authentication. Default: empty, no JWT token authentication will be used.' => '',
    'Application secret shared with a private Jitsi server used to sign JWT token for authentication. Default: empty, needed if JWT token should be generated.' => '',
    'Enable JWT Authentication' => '',
];
