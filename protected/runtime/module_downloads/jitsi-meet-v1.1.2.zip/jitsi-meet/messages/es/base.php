<?php

return [
    '<strong>Jitsi</strong> module configuration' => 'Configuración del módulo <strong>Jitsi</strong>',
    'Close' => 'Cerrar',
    'Default is meet.jit.si without "https://" prefix.' => 'Por defecto es <strong>meet.jit.si</strong> sin el prefijo "https://"',
    'Default: Jitsi Meet' => 'Por defecto: Jitsi Meet',
    'Default: empty, useful for public Jitsi server' => 'Por defecto: vacío, útil para servidor público de Jitsi',
    'Invite' => 'Invitar',
    'Join' => 'Unirse',
    'Name' => 'Nombre',
    'Open conference room' => 'Abrir conferencia',
    'Open in new window?' => 'Abrir en una nueva ventana?',
    'Application ID shared with a private Jitsi server used to generate JWT token for authentication. Default: empty, no JWT token authentication will be used.' => '',
    'Application secret shared with a private Jitsi server used to sign JWT token for authentication. Default: empty, needed if JWT token should be generated.' => '',
    'Enable JWT Authentication' => '',
];
