Changelog
=========

1.1.2 (September 12, 2020)
--------------------------
- Fix #10: Workaround for broken "open in app" link on Android devices
- Fix #11: Authentication failed with Jitsi Password


1.1.0 (April 05, 2020)
----------------------
- Enh #2: Add JWT authentication (thanks to @edmw)
- Fix #4: Added nonce to inline scripts


1.0.0 (March 22, 2020)
----------------------
Initial release