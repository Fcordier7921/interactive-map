<?php

return [
    'Attend' => 'Katılıyorum',
    'Decline' => 'Katılmıyorum',
    'Maybe' => 'Belki',
    'Additional information' => '',
];
