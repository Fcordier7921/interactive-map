<?php

return [
    '<strong>Create</strong> event' => '<strong>Etkinlik</strong> oluştur',
    '<strong>Edit</strong> event' => '<strong>Etkinlik</strong> düzenle',
    'Basic' => 'Temel',
    'Everybody can participate' => 'Herkes katılabilir',
    'Files' => 'Dosyalar',
    'No participants' => 'Katılımsız',
    'Title' => 'Başlık',
    '<strong>Edit</strong> recurring event' => '',
    'Participation' => '',
    'Recurrence' => '',
    'Reminder' => '',
    'Select event type...' => '',
];
