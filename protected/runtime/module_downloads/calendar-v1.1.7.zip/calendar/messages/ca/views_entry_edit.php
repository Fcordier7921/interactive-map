<?php

return [
    '<strong>Create</strong> event' => '<strong>Crea</strong> un event',
    '<strong>Edit</strong> event' => '<strong>Edita</strong> l\'event',
    'Basic' => 'Bàsic',
    'Everybody can participate' => 'Tothom pot participar',
    'Files' => 'Arxius',
    'No participants' => 'No participants',
    'Title' => 'Títol',
    '<strong>Edit</strong> recurring event' => '',
    'Participation' => '',
    'Recurrence' => '',
    'Reminder' => '',
    'Select event type...' => '',
];
