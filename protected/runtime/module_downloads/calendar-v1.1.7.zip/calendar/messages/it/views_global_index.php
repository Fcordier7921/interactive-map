<?php
return array (
  '<strong>Filter</strong> events' => '<strong>Filtro</strong> eventi',
  '<strong>Select</strong> calendars' => '<strong>Seleziona</strong> calendari',
  'Followed spaces' => 'Spazi che seguo',
  'Followed users' => 'Utenti che seguo',
  'I\'m attending' => 'sto partecipando',
  'My events' => 'I miei eventi',
  'My profile' => 'il mio profilo',
  'My spaces' => 'I miei spazi',
);
