<?php
return array (
  ':count attending' => ':count partecipano',
  ':count declined' => ':count non partecipano',
  ':count maybe' => ':count forse partecipano',
  'Participants' => 'Partecipanti',
);
