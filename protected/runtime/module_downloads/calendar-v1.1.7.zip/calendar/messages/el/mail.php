<?php
return array (
  '<strong>Starting</strong> {date}' => '<strong>Εκκίνηση</strong> {date}',
  'Additional information:' => 'Επιπλέον πληροφορίες:',
  'Location:' => 'Τοποθεσία:',
  'Organized by {userName}' => 'Οργανώθηκε από τον χρήστη {userName}',
  'View Online: {url}' => 'Προβολή σε απευθείας σύνδεση: {url}',
);
