<?php
return array (
  '<strong>Filter</strong> events' => '<strong>Φιλτράρισμα</strong> εκδηλώσεων',
  '<strong>Select</strong> calendars' => '<strong>Επιλογή</strong> ημερολογίων',
  'Followed spaces' => 'Ακολουθούμενοι χώροι',
  'Followed users' => 'Ακολουθούμενοι χρήστες',
  'I\'m attending' => 'Παρακολουθώ',
  'My events' => 'Οι εκδηλώσεις μου',
  'My profile' => 'Το προφίλ μου',
  'My spaces' => 'Οι χώροι μου',
);
