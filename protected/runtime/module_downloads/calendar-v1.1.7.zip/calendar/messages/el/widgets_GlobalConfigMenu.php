<?php

return [
    'Defaults' => 'Προεπιλογές',
    'Event Types' => 'Τύποι εκδηλώσεων',
    'Snippet' => 'Απόσπασμα',
    'Calendars' => '',
];
