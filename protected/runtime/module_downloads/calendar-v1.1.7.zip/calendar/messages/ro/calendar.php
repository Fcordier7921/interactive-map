<?php
return array (
  'day' => '',
  'list' => '',
  'month' => '',
  'today' => 'azi',
  'week' => '',
);
