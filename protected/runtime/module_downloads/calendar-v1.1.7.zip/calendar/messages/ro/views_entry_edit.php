<?php

return [
    '<strong>Create</strong> event' => '<strong>Crează</strong> eveniment',
    '<strong>Edit</strong> event' => '<strong>Editează</strong> eveniment',
    'Basic' => 'De bază',
    'Everybody can participate' => 'Oricine poate participa',
    'Files' => 'Fisiere',
    'No participants' => 'Fără participanți',
    'Title' => 'Titlul',
    '<strong>Edit</strong> recurring event' => '',
    'Participation' => '',
    'Recurrence' => '',
    'Reminder' => '',
    'Select event type...' => '',
];
