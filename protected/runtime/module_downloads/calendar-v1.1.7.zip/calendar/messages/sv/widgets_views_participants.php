<?php
return array (
  ':count attending' => ':count deltar',
  ':count declined' => ':count avböjt',
  ':count maybe' => ':count kanske',
  'Participants' => 'Deltagare',
);
