<?php
return array (
  'day' => 'dag',
  'list' => 'lista',
  'month' => 'månad',
  'today' => 'idag',
  'week' => 'vecka',
);
