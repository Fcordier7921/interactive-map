<?php
return array (
  'Calendars' => 'Kalendrar',
  'Defaults' => 'Standardinställning',
  'Event Types' => 'Aktivitetstyper',
  'Snippet' => 'Snippet',
);
