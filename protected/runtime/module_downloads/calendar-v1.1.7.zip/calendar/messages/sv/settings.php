<?php
return array (
  'Participation' => 'Deltagande',
  'Reminder' => 'Påminnelse',
);
