<?php
return array (
  'Additional information' => 'Ytterligare information',
  'Attend' => 'Deltar',
  'Decline' => 'Avböj',
  'Maybe' => 'Kanske',
);
