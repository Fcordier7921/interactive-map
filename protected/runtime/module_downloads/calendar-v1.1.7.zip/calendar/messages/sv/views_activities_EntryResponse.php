<?php
return array (
  '%displayName% cannot attend %contentTitle%.' => '% displayName% kan inte delta i% contentTitle%.',
  '%displayName% is attending %contentTitle%.' => '% displayName% deltar i% contentTitle%.',
  '%displayName% might be attending %contentTitle%.' => '% displayName% kommer kanske att delta i% contentTitle%.',
);
