<?php
return array (
  '{displayName} canceled event "{contentTitle}" in space {spaceName}.' => '{displayName} raderade händelsen "{contentTitle}" i nätverket {spaceName}.',
  '{displayName} canceled event "{contentTitle}".' => '{displayName} raderade händelsen"{contentTitle}"',
  '{displayName} just added you to event "{contentTitle}".' => '{displayName} lade just till dig till "{contentTitle}".',
  '{displayName} just updated event "{contentTitle}" in space {spaceName}.' => '{displayName} uppdaterade händelsen "{contentTitle}" i nätverket {spaceName}.',
  '{displayName} just updated event {contentTitle}.' => '{displayName} uppdaterade {contentTitle}.',
  '{displayName} reopened event "{contentTitle}" in space {spaceName}.' => '{displayName} återaktiverade händelsen "{contentTitle}" i nätverket {spaceName}.',
  '{displayName} reopened event "{contentTitle}".' => '{displayName} återaktiverade händelsen "{contentTitle}"',
);
