<?php
return array (
  '<strong>Upcoming</strong> events ' => '<strong>Kommande</strong> aktiviteter',
  'Open Calendar' => 'Öppna kalender',
);
