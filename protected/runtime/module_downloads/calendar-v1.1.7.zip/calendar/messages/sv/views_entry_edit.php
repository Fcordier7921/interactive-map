<?php
return array (
  '<strong>Create</strong> event' => '<strong>Skapa</strong> aktivitet',
  '<strong>Edit</strong> event' => '<strong>Ändra</strong> aktivitet',
  '<strong>Edit</strong> recurring event' => '<strong>Ändra</strong> återkommande aktivitet',
  'Basic' => 'Grundläggande',
  'Everybody can participate' => 'Alla kan delta',
  'Files' => 'Filer',
  'No participants' => 'Inga deltagare',
  'Participation' => 'Deltagande',
  'Recurrence' => 'Återkommande',
  'Reminder' => 'Påminnelse',
  'Select event type...' => 'Välj aktivitetstyp',
  'Title' => 'Rubrik',
);
