<?php
return array (
  '<strong>Starting</strong> {date}' => '<strong>Med början</strong> {date}',
  'Additional information:' => 'Ytterligare information:',
  'Location:' => 'Plats:',
  'Organized by {userName}' => 'Arrangerad av {userName}',
  'View Online: {url}' => 'Se Online: {url}',
);
