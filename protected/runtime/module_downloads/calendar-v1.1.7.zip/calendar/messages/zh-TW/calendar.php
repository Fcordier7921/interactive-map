<?php
return array (
  'day' => '',
  'list' => '',
  'month' => '',
  'today' => '今天',
  'week' => '',
);
