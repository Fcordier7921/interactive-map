<?php
return array (
  'day' => '',
  'list' => 'ليست',
  'month' => '',
  'today' => 'امروز',
  'week' => '',
);
