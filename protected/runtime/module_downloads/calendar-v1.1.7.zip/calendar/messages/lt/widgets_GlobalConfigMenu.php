<?php

return [
    'Defaults' => 'Numatytieji',
    'Calendars' => '',
    'Event Types' => '',
    'Snippet' => '',
];
