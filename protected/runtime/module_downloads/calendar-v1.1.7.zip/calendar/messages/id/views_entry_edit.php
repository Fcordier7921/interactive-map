<?php

return [
    '<strong>Create</strong> event' => 'buat acara',
    '<strong>Edit</strong> event' => 'Ubah acara',
    'Basic' => 'Dasar',
    'Everybody can participate' => 'Semua orang dapat berpartisipasi',
    'Files' => 'Files',
    'No participants' => 'Tidak berpartisipasi',
    'Title' => 'Judul',
    '<strong>Edit</strong> recurring event' => '',
    'Participation' => '',
    'Recurrence' => '',
    'Reminder' => '',
    'Select event type...' => '',
];
