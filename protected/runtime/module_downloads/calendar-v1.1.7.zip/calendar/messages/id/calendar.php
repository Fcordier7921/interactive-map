<?php
return array (
  'day' => '',
  'list' => '',
  'month' => '',
  'today' => 'Hari ini',
  'week' => '',
);
