<?php
return array (
  '<strong>Create</strong> event' => '<strong>Criar</strong> evento',
  '<strong>Edit</strong> event' => '<strong>Alterar</strong> evento',
  '<strong>Edit</strong> recurring event' => '<strong> Editar </strong> evento recorrente',
  'Basic' => 'Básico',
  'Everybody can participate' => 'Todos podem participar',
  'Files' => 'Arquivos',
  'No participants' => 'Sem participantes',
  'Participation' => 'Participação',
  'Recurrence' => 'Recorrência',
  'Reminder' => 'Lembrete',
  'Select event type...' => 'Selecionar tipo de evento...',
  'Title' => 'Título',
);
