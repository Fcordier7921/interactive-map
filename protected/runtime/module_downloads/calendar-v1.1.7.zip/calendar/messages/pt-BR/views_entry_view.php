<?php
return array (
  'Additional information' => 'Informações adicionais',
  'Attend' => 'Participar',
  'Decline' => 'Recusar',
  'Maybe' => 'Talvez',
);
