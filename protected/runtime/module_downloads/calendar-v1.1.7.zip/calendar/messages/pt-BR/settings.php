<?php
return array (
  'Participation' => 'Participação',
  'Reminder' => 'Lembrete',
);
