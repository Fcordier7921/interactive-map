<?php
return array (
  '%displayName% cannot attend %contentTitle%.' => '% displayName% não pode comparecer a% contentTitle%.',
  '%displayName% is attending %contentTitle%.' => '% displayName% está participando de% contentTitle%.',
  '%displayName% might be attending %contentTitle%.' => '% displayName% pode estar participando de% contentTitle%.',
);
