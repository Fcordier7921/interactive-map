<?php
return array (
  '<strong>Starting</strong> {date}' => '<strong> Início </strong> {date}',
  'Additional information:' => 'Informações adicionais:',
  'Location:' => 'Localização:',
  'Organized by {userName}' => 'Organizado por {userName}',
  'View Online: {url}' => 'Ver online: {url}',
);
