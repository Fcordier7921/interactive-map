<?php
return array (
  'day' => 'dia',
  'list' => 'lista',
  'month' => 'mês',
  'today' => 'hoje',
  'week' => 'semana',
);
