<?php
return array (
  ':count attending' => ':count participando',
  ':count declined' => ':count recusaram',
  ':count maybe' => ':count talvez',
  'Participants' => 'Participantes',
);
