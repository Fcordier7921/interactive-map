<?php
return array (
  '%displayName% cannot attend %contentTitle%.' => '%displayName% ne participe pas à %contentTitle%.',
  '%displayName% is attending %contentTitle%.' => '%displayName% participe à %contentTitle%.',
  '%displayName% might be attending %contentTitle%.' => '%displayName% participera peut-être à %contentTitle%.',
);
