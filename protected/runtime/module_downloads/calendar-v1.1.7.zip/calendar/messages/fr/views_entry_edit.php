<?php
return array (
  '<strong>Create</strong> event' => '<strong>Créer</strong> un événement',
  '<strong>Edit</strong> event' => '<strong>Modifier</strong> un événement',
  '<strong>Edit</strong> recurring event' => '<strong>Modifier</strong> l\'évènement récurrent',
  'Basic' => 'Général',
  'Everybody can participate' => 'Tout le monde peut participer',
  'Files' => 'Fichiers',
  'No participants' => 'Pas de participants',
  'Participation' => 'Participation',
  'Recurrence' => 'Répétions',
  'Reminder' => 'Rappel',
  'Select event type...' => 'Sélectionner le type d\'événement...',
  'Title' => 'Titre',
);
