<?php
return array (
  'Calendars' => 'Calendriers',
  'Defaults' => 'Général',
  'Event Types' => 'Types',
  'Snippet' => 'Extrait',
);
