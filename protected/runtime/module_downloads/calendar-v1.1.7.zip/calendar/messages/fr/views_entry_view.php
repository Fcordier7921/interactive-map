<?php
return array (
  'Additional information' => 'Informations additionnelles :',
  'Attend' => 'Participer',
  'Decline' => 'Décliner',
  'Maybe' => 'Peut-être',
);
