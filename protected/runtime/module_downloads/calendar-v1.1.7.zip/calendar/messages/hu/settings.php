<?php
return array (
  'Participation' => 'Részvétel',
  'Reminder' => 'Emlékeztető',
);
