<?php
return array (
  '<strong>Upcoming</strong> events ' => '<strong>Közelgő</strong> események',
  'Open Calendar' => 'Naptár megnyitása',
);
