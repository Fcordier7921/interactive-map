<?php
return array (
  '%displayName% created a new %contentTitle%.' => '%displayName% létrehozott egy új %contentTitle%.',
);
