<?php
return array (
  '<strong>Create</strong> new event type' => 'Új eseménytípus <strong>létrehozása</strong>',
  '<strong>Edit</strong> calendar' => 'Naptár <strong>szerkesztése</strong>',
  '<strong>Edit</strong> event type' => 'Eseménytípus <strong>szerkesztése</strong>',
);
