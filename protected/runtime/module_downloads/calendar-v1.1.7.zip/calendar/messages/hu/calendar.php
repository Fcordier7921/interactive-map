<?php
return array (
  'day' => 'nap',
  'list' => 'lista',
  'month' => 'hónap',
  'today' => 'ma',
  'week' => 'hét',
);
