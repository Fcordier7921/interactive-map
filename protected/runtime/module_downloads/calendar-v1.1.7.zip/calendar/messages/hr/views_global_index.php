<?php
return array (
  '<strong>Filter</strong> events' => '<strong>Filter</strong> događaja',
  '<strong>Select</strong> calendars' => '<strong>Odaberi</strong> kalendare',
  'Followed spaces' => 'Praćeni prostori',
  'Followed users' => 'Praćeni korisnici',
  'I\'m attending' => 'Ja prisustvujem',
  'My events' => 'Moji događaji',
  'My profile' => 'Moj profil',
  'My spaces' => 'Moji prostori',
);
