<?php
return array (
  'Participation' => 'Sudjelovanje',
  'Reminder' => 'Podsjetnik',
);
