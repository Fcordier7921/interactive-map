<?php
return array (
  '<strong>Create</strong> event' => '<strong>Kreiraj</strong> događaj',
  '<strong>Edit</strong> event' => '<strong>Uredi</strong> događaj',
  '<strong>Edit</strong> recurring event' => '<strong>Uredi</strong> ponavljajući događaj',
  'Basic' => 'Osnovno',
  'Everybody can participate' => 'Svi mogu sudjelovati',
  'Files' => 'Datoteke',
  'No participants' => 'Nema sudionika',
  'Participation' => 'Sudjelovanje',
  'Recurrence' => 'Ponavljanje',
  'Reminder' => 'Podsjetnik',
  'Select event type...' => 'Odaberite tip događaja...',
  'Title' => 'Naziv',
);
