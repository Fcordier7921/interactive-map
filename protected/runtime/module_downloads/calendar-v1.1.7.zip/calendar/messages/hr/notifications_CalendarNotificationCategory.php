<?php
return array (
  'Calendar' => 'Kalendar',
  'Receive Calendar related Notifications.' => 'Primajte obavijesti vezane uz kalendar.',
);
