<?php

return [
    '<strong>Create</strong> event' => '<strong>创建</strong> 事件',
    '<strong>Edit</strong> event' => '<strong>编辑</strong> 事件',
    'Basic' => '基础',
    'Everybody can participate' => '所有人能参加',
    'Files' => '附件设置',
    'No participants' => '没有参与者',
    'Title' => '标题',
    '<strong>Edit</strong> recurring event' => '',
    'Participation' => '',
    'Recurrence' => '',
    'Reminder' => '',
    'Select event type...' => '',
];
