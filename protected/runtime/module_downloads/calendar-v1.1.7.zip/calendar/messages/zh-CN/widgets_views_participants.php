<?php

return [
    ':count attending' => ':count 参加',
    ':count declined' => ':count 拒绝',
    ':count maybe' => ':count 可能',
    'Participants' => '',
];
