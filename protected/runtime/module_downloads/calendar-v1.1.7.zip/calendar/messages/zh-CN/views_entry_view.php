<?php

return [
    'Attend' => '参加',
    'Decline' => '拒绝',
    'Maybe' => '可能',
    'Additional information' => '',
];
