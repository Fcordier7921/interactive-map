<?php
return array (
  'Additional information' => '',
  'Attend' => '',
  'Decline' => 'דחה',
  'Maybe' => '',
);
