<?php
return array (
  'Additional information' => 'Extra informatie',
  'Attend' => 'Deelnemen',
  'Decline' => 'Afwijzen',
  'Maybe' => 'Misschien',
);
