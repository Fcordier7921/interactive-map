<?php
return array (
  'Participation' => 'Deelnemen',
  'Reminder' => 'Herinnering',
);
