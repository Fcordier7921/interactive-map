<?php
return array (
  'day' => 'dag',
  'list' => 'lijst',
  'month' => 'maand',
  'today' => 'vandaag',
  'week' => 'week',
);
