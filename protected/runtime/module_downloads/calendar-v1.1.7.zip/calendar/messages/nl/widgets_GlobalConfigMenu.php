<?php
return array (
  'Calendars' => 'Agenda\\\'s',
  'Defaults' => 'Standaard instellingen',
  'Event Types' => 'Gebeurtenis-types',
  'Snippet' => 'Codefragment',
);
