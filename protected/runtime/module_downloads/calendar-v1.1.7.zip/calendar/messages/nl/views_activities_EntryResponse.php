<?php
return array (
  '%displayName% cannot attend %contentTitle%.' => '%displayName% kan %contentTitle% niet bijwonen.',
  '%displayName% is attending %contentTitle%.' => '%displayName% gaat naar %contentTitle%.',
  '%displayName% might be attending %contentTitle%.' => '%displayName% is mogelijk aanwezig op %contentTitle%.',
);
