<?php
return array (
  ':count attending' => ':count человек посетит',
  ':count declined' => ':count отказалось посетить',
  ':count maybe' => ':count возможно посетят',
  'Participants' => 'Участники',
);
