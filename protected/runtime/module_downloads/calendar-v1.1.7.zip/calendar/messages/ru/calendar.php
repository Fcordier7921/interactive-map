<?php
return array (
  'day' => '',
  'list' => 'список',
  'month' => '',
  'today' => 'сегодня',
  'week' => '',
);
