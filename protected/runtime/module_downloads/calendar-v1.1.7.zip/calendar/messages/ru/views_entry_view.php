<?php

return [
    'Attend' => 'Посетить',
    'Decline' => 'Отказать',
    'Maybe' => 'Возможно',
    'Additional information' => '',
];
