<?php

return [
    'Defaults' => 'По-умолчанию',
    'Calendars' => '',
    'Event Types' => '',
    'Snippet' => '',
];
