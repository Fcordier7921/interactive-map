<?php
return array (
  'Calendars' => 'Kalendarze',
  'Defaults' => 'Domyślne',
  'Event Types' => 'Typy wydarzeń',
  'Snippet' => 'Panel',
);
