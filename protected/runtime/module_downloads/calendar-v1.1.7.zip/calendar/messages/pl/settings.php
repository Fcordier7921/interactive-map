<?php
return array (
  'Participation' => 'Uczestnictwo',
  'Reminder' => 'Przypomnienia',
);
