<?php
return array (
  'day' => 'dzień',
  'list' => 'lista',
  'month' => 'miesiąc',
  'today' => 'dzisiaj',
  'week' => 'tydzień',
);
