<?php

return [
    'Attend' => 'Wezmę udział',
    'Decline' => 'Odrzuć',
    'Maybe' => 'Może',
    'Additional information' => '',
];
