<?php
return array (
  'Allows the user to create new calendar entries' => 'Pozwala użytkownikom tworzyć nowe pozycje w kalendarzu',
  'Allows the user to edit/delete existing calendar entries' => 'Pozwala użytkownikom edytować/usuwać istniejące pozycje w kalendarzu',
  'Create entry' => 'Tworzenie pozycji',
  'Manage entries' => 'Zarządzanie pozycjami',
);
