<?php
return array (
  'Recipient' => 'Destinataire',
  'User {name} is already participating!' => 'L\'utilisateur {name} participe déjà.',
  'You are not allowed to send user {name} is already!' => 'Vous n\'êtes pas autoriser à envoyer de massage à l\'utilisateur {name}.',
  'You cannot send a email to yourself!' => 'Vous ne pouvez pas envoyer un e-mail à vous-même.',
);
