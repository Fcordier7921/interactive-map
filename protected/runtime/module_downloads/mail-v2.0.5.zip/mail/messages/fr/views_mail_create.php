<?php
return array (
  '<strong>New</strong> message' => '<strong>Nouveau</strong> message',
  'Add recipients' => 'Ajouter des destinataires',
  'Send' => 'Envoyer',
);
