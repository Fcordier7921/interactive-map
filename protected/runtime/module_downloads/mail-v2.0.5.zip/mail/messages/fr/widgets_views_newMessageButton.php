<?php

return [
    'Send message' => 'Envoyer un message',
];
