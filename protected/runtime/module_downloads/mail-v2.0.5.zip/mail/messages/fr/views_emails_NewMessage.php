<?php

return [
    '<strong>New</strong> message' => '<strong>Nouveau</strong> message',
    'Reply now' => 'Répondre maintenant',
];
