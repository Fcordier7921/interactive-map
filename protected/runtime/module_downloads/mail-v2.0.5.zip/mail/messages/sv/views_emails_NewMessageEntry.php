<?php
return array (
  'sent you a new message in' => 'sände dig ett nytt meddelande i',
);
