<?php

return [
    'Conversations' => 'Konversationer',
    'New' => 'Nytt',
    'There are no messages yet.' => 'Det finns inga meddelanden ännu.',
];
