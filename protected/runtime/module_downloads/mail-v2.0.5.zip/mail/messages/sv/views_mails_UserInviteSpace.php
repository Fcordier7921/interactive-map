<?php
return array (
  'Sign up now' => 'Gå med nu',
);
