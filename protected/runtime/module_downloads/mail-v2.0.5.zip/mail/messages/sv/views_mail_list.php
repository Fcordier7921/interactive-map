<?php
return array (
  'There are no messages yet.' => 'Det finns inga meddelanden ännu.',
);
