<?php

return [
    'Add more participants to your conversation...' => 'lägg till fler deltagare i din diskussion...',
];
