<?php
return array (
  'New message in discussion from %displayName%' => 'Nytt meddelande i diskussion med %displayName%',
);
