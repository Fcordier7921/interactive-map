<?php
return array (
  'Groups' => 'Grupper',
  'Members' => 'Medlemmar',
  'Spaces' => 'Nätverk ',
  'User Posts' => 'Användarinlägg',
);
