<?php

return [
    'Send message' => 'Sänd meddelande',
];
