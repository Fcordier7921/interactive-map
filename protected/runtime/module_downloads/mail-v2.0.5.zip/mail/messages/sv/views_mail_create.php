<?php
return array (
  '<strong>New</strong> message' => '<strong>Nytt</strong> medelande',
  'Add recipients' => 'Lägg till mottagare',
  'Send' => 'Sänd',
);
