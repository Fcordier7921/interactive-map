<?php
return array (
  'Sign up now' => 'Đăng ký ngay',
);
