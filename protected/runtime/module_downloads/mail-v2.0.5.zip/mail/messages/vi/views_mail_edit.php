<?php

return [
    'Edit message entry' => 'Chỉnh sửa tin nhắn',
];
