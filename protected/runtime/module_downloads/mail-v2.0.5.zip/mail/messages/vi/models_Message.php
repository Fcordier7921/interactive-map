<?php

return [
    'New message from {senderName}' => 'Tin nhắn mới từ {senderName}',
];
