<?php

return [
    'Conversations' => 'Hội thoại',
    'New' => 'Mới',
    'There are no messages yet.' => 'Chưa có tin nhắn nào.',
];
