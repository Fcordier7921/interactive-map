<?php

return [
    'User {name} is already participating!' => '',
    'You are not allowed to send user {name} is already!' => '',
    'Recipient' => 'Người nhận',
    'You cannot send a email to yourself!' => 'Bạn không thể gửi thư cho chính mình!',
];
