<?php
return array (
  'Message' => 'Mensagem',
  'Recipient' => 'Destinatário',
  'Subject' => 'Assunto',
  'Tags' => 'Tags',
);
