<?php
return array (
  'Message' => 'Μήνυμα',
  'Recipient' => '',
  'Subject' => 'Θέμα',
  'Tags' => 'Λέξεις κλειδιά',
);
