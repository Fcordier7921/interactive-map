<?php

return [
    'Show all messages' => 'Показать все сообщения',
];
