<?php

return [
    '<strong>New</strong> message' => '',
    'Reply now' => '',
];
