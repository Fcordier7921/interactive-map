<?php

return [
    '<strong>New</strong> message' => '',
    'Add recipients' => '',
    'Send' => '',
];
