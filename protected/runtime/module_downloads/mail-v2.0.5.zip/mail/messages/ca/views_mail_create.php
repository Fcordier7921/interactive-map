<?php
return array (
  '<strong>New</strong> message' => '<strong>Nou</strong> missatge',
  'Add recipients' => '',
  'Send' => 'Envia',
);
