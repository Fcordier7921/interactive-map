<?php

return [
    '<strong>New</strong> message' => '<strong>Nuovo</strong> messaggio',
    'Reply now' => 'Rispondi ora',
];
