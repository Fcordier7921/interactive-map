<?php
return array (
  'sent you a new message in' => 'به شما یک پیغام جدید فرستاد در',
);
