<?php

return [
    '<strong>New</strong> message' => 'پیغام <strong>جدید</strong>',
    'Reply now' => 'الان پاسخ دهید',
];
