<?php

return [
    'Add more participants to your conversation...' => 'شرکت‌کننده‌های دیگری به مکالمه‌ی خود اضافه کنید. . .',
];
