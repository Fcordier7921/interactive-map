<?php

return [
    'Send message' => 'Üzenetküldés',
];
