<?php
return array (
  '<strong>New</strong> message' => '<strong>Új</strong> üzenet',
  'Add recipients' => 'Címzettek',
  'Send' => 'Küldés',
);
