<?php

return [
    'Send message' => 'Siųsti žinutę',
];
