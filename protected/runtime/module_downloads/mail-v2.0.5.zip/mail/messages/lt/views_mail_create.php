<?php
return array (
  '<strong>New</strong> message' => '<strong>Nauja</strong> žinutė',
  'Add recipients' => '',
  'Send' => 'Išsiųsti',
);
