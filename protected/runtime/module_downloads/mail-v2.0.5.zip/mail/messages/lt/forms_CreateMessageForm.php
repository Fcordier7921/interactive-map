<?php
return array (
  'Message' => 'Žinutė',
  'Recipient' => 'Gavėjas',
  'Subject' => 'Tema',
  'Tags' => 'Žymos',
);
