<?php

return [
    'Send message' => 'Sūtīt ziņojumu',
];
