<?php
return array (
  '<strong>New</strong> message' => '<strong>Nieuw</strong> bericht',
  'Add recipients' => 'Ontvangers toevoegen',
  'Send' => 'Verstuur',
);
