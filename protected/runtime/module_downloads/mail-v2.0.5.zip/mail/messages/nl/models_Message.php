<?php

return [
    'New message from {senderName}' => 'Nieuw bericht van {senderName}',
];
