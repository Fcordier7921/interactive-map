<?php
return array (
  'Message' => 'Besked',
  'Recipient' => 'Modtager',
  'Subject' => 'Emne',
  'Tags' => 'Tags',
);
