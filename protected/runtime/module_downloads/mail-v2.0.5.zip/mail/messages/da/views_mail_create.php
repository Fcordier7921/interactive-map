<?php
return array (
  '<strong>New</strong> message' => '<strong>Ny</strong> besked',
  'Add recipients' => 'Tilføjet modtagere',
  'Send' => 'Send',
);
