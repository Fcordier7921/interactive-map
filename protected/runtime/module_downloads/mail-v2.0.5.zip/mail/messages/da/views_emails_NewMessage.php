<?php

return [
    '<strong>New</strong> message' => '<strong>Ny</strong> besked',
    'Reply now' => 'Svar nu',
];
