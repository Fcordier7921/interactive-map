<?php

return [
    'New message from {senderName}' => 'Ny besked fra {senderName}',
];
