<?php

return [
    'New message from {senderName}' => '来自 {senderName} 的新消息',
];
