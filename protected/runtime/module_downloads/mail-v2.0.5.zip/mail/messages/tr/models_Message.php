<?php

return [
    'New message from {senderName}' => 'Yeni mesaj var. Gönderen {senderName}',
];
