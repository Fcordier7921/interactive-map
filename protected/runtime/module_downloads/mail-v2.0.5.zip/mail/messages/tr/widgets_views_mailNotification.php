<?php

return [
    'Show all messages' => 'Tüm mesajları göster',
];
