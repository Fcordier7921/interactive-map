<?php
return array (
  '<strong>New</strong> message' => '<strong>Yeni</strong> mesaj',
  'Add recipients' => 'Alıcıları ekle',
  'Send' => 'Gönder',
);
