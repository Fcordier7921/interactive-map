<?php

return [
    'Completed' => '',
    'Title' => '',
];
