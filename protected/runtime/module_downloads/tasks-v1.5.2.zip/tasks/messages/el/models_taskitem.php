<?php
return array (
  'Completed' => '',
  'Title' => 'Τίτλος',
);
