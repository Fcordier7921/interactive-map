<?php
return array (
  'Created by me' => 'ایجادشده توسط من',
  'End date' => '',
  'Filter status' => '',
  'Filter tasks' => '',
  'I\'m assigned' => '',
  'I\'m responsible' => '',
  'Overdue' => '',
  'Spaces' => 'انجمن‌ها',
  'Start date' => '',
  'Status' => 'وضعیت',
  'Title' => 'عنوان',
);
