<?php
return array (
  '{userName} created a new task {task}.' => '{userName} создал новую задачу {task}.',
);
