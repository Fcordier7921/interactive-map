<?php
return array (
  'Already requested' => 'Već zatraženo',
  'Request sent' => 'Zahtjev poslan',
  'You have insufficient permissions to perform that operation!' => 'Nemate ovlaštenje za provođenje ove operacije!',
);
