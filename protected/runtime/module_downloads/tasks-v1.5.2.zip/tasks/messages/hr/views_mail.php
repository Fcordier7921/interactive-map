<?php
return array (
  'Your Reminder for task {task}' => 'Vaš podsjetnik za zadatak {task}',
);
