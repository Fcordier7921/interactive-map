<?php
return array (
  '{userName} finished task {task}.' => '{userName} izvršio je zadatak {task}.',
);
