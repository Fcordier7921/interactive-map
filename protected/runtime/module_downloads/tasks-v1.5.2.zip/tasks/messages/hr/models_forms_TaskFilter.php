<?php
return array (
  'Created by me' => 'Kreirao sam',
  'End date' => 'Datum završetka',
  'Filter status' => 'Filter statusa',
  'Filter tasks' => 'Filter zadataka',
  'I\'m assigned' => 'Dodijeljen sam',
  'I\'m responsible' => 'Ja sam odgovoran',
  'Overdue' => 'Zakašnjelo',
  'Spaces' => 'Prostori',
  'Start date' => 'Početni datum',
  'Status' => 'Status',
  'Title' => 'Naziv',
);
