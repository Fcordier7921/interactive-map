<?php
return array (
  'Completed' => 'Dovršeno',
  'Title' => 'Naziv',
);
