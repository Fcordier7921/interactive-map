<?php

return [
    'Drag list' => '',
];
