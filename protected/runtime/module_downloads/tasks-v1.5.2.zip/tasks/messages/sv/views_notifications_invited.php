<?php

return [
    '{userName} assigned you as responsible person in task {task} from space {spaceName}.' => '',
];
