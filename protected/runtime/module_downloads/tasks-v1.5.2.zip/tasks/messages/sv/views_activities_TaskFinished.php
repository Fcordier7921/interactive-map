<?php
return array (
  '{userName} finished task {task}.' => '{userName} avslutade uppgiften {task}.',
);
