<?php
return array (
  '{userName} created task {task}.' => '{userName} skapade uppgiften {task}.',
);
