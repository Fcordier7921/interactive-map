<?php
return array (
  'Click, to finish this task' => 'Klicka för att göra klart uppgiften!',
  'This task is already done. Click to reopen.' => 'Uppgiften är avslutad. Klicka för att aktivera den igen!',
);
