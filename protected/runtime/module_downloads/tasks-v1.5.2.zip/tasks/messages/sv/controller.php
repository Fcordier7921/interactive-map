<?php
return array (
  'Already requested' => '',
  'Request sent' => 'Begäran skickad',
  'You have insufficient permissions to perform that operation!' => '',
);
