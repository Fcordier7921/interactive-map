<?php
return array (
  'Anyone can work on this task!' => 'Qualquer um pode trabalhar nessa tarefa!',
  'Open Task' => 'Tarefa aberta',
  'This task can only be processed by assigned and responsible users.' => 'Esta tarefa pode ser processada apenas por usuários designados e responsáveis.',
);
