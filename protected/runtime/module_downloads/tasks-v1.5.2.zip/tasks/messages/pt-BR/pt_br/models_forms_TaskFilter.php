<?php
return array (
  'Created by me' => 'Criado por mim',
  'End date' => '',
  'Filter status' => '',
  'Filter tasks' => '',
  'I\'m assigned' => '',
  'I\'m responsible' => '',
  'Overdue' => '',
  'Spaces' => 'Espaços',
  'Start date' => '',
  'Status' => 'Status',
  'Title' => 'Título',
);
