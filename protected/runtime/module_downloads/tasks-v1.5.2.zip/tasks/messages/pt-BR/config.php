<?php
return array (
  '<strong>Task</strong> module configuration' => 'Configuração do módulo <strong> Tarefa </strong>',
  'Displays a global task menu item on the main menu.' => 'Exibe um item do menu de tarefas globais no menu principal.',
  'Global task menu item' => 'Item de menu de tarefas globais',
  'Max tasks items' => 'Itens de tarefas máximas',
  'Menu Item sort order' => 'Ordem de classificação dos itens de menu',
  'Show global task menu item' => 'Mostrar item de menu da tarefa global',
  'Show snippet' => 'Mostrar trecho',
  'Show snippet in Space' => 'Mostrar trecho no espaço',
  'Shows a widget with tasks on the dashboard where you are assigned/responsible.' => 'Mostra um widget com tarefas no painel em que você é designado / responsável.',
  'Shows the widget also on the dashboard of spaces.' => 'Mostra o widget também no painel de espaços.',
  'Sort order' => 'Ordem de classificação',
  'Your tasks snippet' => 'Seu snippet de tarefas',
);
