<?php
return array (
  'Task Users have been notified' => 'Tarefa Os usuários foram notificados',
);
