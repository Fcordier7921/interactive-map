<?php
return array (
  'Created by me' => '我创建的',
  'End date' => '',
  'Filter status' => '',
  'Filter tasks' => '',
  'I\'m assigned' => '',
  'I\'m responsible' => '',
  'Overdue' => '',
  'Spaces' => '空间',
  'Start date' => '',
  'Status' => '状态',
  'Title' => '标题',
);
