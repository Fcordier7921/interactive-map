<?php
return array (
  'End Date' => '结束日期',
  'End Time' => '',
  'End time must be after start time!' => '结束时间必须晚于开始时间！',
  'Public' => '公共',
  'Start Date' => '开始日期',
  'Start Time' => '',
  'Time Zone' => '',
);
