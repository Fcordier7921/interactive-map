<?php
return array (
  '{userName} finished task {task}.' => '{task} 完成任务 {userName} .',
);
