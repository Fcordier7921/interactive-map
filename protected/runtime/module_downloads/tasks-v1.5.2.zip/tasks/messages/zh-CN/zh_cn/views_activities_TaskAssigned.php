<?php
return array (
  '{userName} assigned to task {task}.' => '{userName} 指定任务 {task}.',
);
