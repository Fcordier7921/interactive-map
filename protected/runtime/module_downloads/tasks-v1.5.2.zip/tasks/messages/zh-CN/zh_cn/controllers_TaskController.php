<?php
return array (
  'Could not access task!' => '无法访问任务!',
);
