<?php

return [
    'Message' => 'Pesan',
    'Recipient' => '',
    'Subject' => '',
    'Tags' => '',
];
