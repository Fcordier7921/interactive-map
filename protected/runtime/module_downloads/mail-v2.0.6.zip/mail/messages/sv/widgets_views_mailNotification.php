<?php

return [
    'Show all messages' => 'Visa alla meddelanden',
];
