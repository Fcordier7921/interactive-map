<?php
return array (
  'Message' => 'Meddelande',
);
