<?php
return array (
  'New message in discussion from %displayName%' => 'Nytt meddelande i diskussionen med %displayName%',
);
