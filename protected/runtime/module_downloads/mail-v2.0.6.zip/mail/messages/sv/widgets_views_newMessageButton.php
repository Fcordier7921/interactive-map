<?php
return array (
  'Send message' => 'Skicka meddelande',
);
