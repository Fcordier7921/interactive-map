<?php

return [
    '<strong>Confirm</strong> deleting conversation' => '<strong>Bekräfta</strong> radering av konversation',
    '<strong>Confirm</strong> leaving conversation' => '<strong>Bekräfta</strong> att du lämnar konversationen',
    '<strong>Confirm</strong> message deletion' => '<strong>Bekräfta</strong> radering av meddelande',
    'Add user' => 'Lägg till användare',
    'Cancel' => 'Avbryt',
    'Delete' => 'Ta bort',
    'Delete conversation' => 'Radera konversation',
    'Do you really want to delete this conversation?' => 'Vill du verkligen radera konversationen?',
    'Do you really want to delete this message?' => 'Vill du verkligen radera detta meddelande?',
    'Do you really want to leave this conversation?' => 'Vill du verkligen lämna denna konversation?',
    'Leave' => 'Lämna',
    'Leave conversation' => 'Lämna konversation',
    'There are no messages yet.' => 'Det finns inga meddelanden ännu.',
];
