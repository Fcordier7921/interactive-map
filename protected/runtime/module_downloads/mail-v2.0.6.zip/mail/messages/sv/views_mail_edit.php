<?php

return [
    'Edit message entry' => 'Ändra meddelandeinlägg',
];
