<?php
return array (
  'Message' => 'Tin nhắn',
  'Recipient' => 'Người nhận',
  'Subject' => 'Chủ đề',
  'Tags' => 'Thẻ',
);
