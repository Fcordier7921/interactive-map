<?php

return [
    'Send message' => 'Gửi tin nhắn',
];
