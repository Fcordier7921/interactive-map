<?php
return array (
  'Groups' => 'Nhóm',
  'Members' => 'Thành viên',
  'Spaces' => 'Phòng làm việc',
  'User Posts' => 'User Posts',
);
