<?php
return array (
  'New message in discussion from %displayName%' => 'Nova mensagem em discussão de %displayName%',
);
