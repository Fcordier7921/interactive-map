<?php

return [
    'Conversations' => 'Conversas',
    'New' => 'Nova',
    'There are no messages yet.' => 'Não há mensagens ainda.',
];
