<?php

return [
    'Send message' => 'Enviar mensagem',
];
