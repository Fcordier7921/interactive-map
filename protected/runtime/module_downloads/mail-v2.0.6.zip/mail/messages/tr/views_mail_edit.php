<?php

return [
    'Edit message entry' => 'Mesaj düzenleme',
];
