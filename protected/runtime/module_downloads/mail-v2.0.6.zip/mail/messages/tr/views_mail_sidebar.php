<?php
return array (
  'Groups' => 'Gruplar',
  'Members' => 'Kullanıcılar',
  'Spaces' => 'Mekanlar',
  'User Posts' => 'Gönderiler',
);
