<?php

return [
    'Send message' => 'Mesaj gönder',
];
