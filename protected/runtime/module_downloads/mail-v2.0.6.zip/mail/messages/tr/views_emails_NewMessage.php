<?php

return [
    '<strong>New</strong> message' => '<strong>Yeni</strong> mesaj',
    'Reply now' => 'Cevapla',
];
