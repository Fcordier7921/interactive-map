<?php

return [
    'Conversations' => 'Konuşmalar',
    'New' => 'Yeni',
    'There are no messages yet.' => 'Henüz mesaj bulunmuyor.',
];
