<?php

return [
    'Edit message entry' => 'Üzenet szerkesztése',
];
