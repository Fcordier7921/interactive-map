<?php

return [
    '<strong>Confirm</strong> deleting conversation' => '<strong>Confirmer</strong> la suppression de la conversation',
    '<strong>Confirm</strong> leaving conversation' => '<strong>Confirmer</strong> le départ de la conversation',
    '<strong>Confirm</strong> message deletion' => '<strong>Confirmer</strong> la suppression du message',
    'Add user' => 'Ajouter un utilisateur',
    'Cancel' => 'Annuler',
    'Delete' => 'Supprimer',
    'Delete conversation' => 'Supprimer la conversation',
    'Do you really want to delete this conversation?' => 'Souhaitez-vous vraiment supprimer cette conversation ?',
    'Do you really want to delete this message?' => 'Souhaitez-vous vraiment supprimer ce message ?',
    'Do you really want to leave this conversation?' => 'Souhaitez-vous vraiment quitter cette conversation ?',
    'Leave' => 'Quitter',
    'Leave conversation' => 'Quitter la conversation',
    'There are no messages yet.' => 'Il n\'y a encore aucun message.',
];
