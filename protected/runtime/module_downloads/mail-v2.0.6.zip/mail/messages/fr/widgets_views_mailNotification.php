<?php

return [
    'Show all messages' => 'Afficher tous les messages',
];
