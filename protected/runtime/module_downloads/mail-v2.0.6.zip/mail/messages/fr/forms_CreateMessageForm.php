<?php
return array (
  'Message' => 'Message',
  'Recipient' => 'Destinataire',
  'Subject' => 'Sujet',
  'Tags' => 'Mots-clés',
);
