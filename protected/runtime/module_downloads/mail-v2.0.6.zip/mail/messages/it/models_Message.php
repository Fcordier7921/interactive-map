<?php

return [
    'New message from {senderName}' => 'Nuovo messaggio da {senderName}',
];
