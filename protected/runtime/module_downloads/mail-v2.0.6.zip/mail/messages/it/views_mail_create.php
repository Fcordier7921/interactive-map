<?php
return array (
  '<strong>New</strong> message' => '<strong>Nuovo</strong> messaggio',
  'Add recipients' => 'Aggiungi destinatari',
  'Send' => 'Invia',
);
