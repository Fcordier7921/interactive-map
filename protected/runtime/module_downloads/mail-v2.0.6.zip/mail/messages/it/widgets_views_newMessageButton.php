<?php

return [
    'Send message' => 'Invia messaggio',
];
