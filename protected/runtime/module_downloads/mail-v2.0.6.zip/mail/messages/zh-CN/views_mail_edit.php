<?php

return [
    'Edit message entry' => '编辑',
];
