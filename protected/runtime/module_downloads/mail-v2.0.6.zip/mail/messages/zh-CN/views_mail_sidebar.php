<?php
return array (
  'Groups' => '组',
  'Members' => '成员',
  'Spaces' => '版块',
  'User Posts' => '用户的帖子',
);
