<?php

return [
    'New message from {senderName}' => 'پیغام جدید از {senderName}',
];
