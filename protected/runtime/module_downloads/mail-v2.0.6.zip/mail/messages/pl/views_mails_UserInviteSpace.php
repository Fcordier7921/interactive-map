<?php
return array (
  'Sign up now' => 'Zarejestruj się teraz ',
);
