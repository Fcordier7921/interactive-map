<?php

return [
    'Edit message entry' => 'Bericht bewerken',
];
