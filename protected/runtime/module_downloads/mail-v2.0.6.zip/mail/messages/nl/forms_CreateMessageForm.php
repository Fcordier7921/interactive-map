<?php
return array (
  'Message' => 'Bericht',
  'Recipient' => 'Ontvanger',
  'Subject' => 'Onderwerp',
  'Tags' => 'Labels',
);
