<?php

return [
    'New message from {senderName}' => 'Nou missatge de {senderName}',
];
