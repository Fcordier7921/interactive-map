<?php

return [
    'Show all messages' => 'Mostra tots els missatges',
];
