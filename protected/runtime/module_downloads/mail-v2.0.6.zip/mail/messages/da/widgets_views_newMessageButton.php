<?php

return [
    'Send message' => 'Send besked',
];
