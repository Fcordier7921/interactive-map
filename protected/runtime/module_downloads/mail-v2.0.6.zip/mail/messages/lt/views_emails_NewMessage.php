<?php

return [
    '<strong>New</strong> message' => '<strong>Nauja</strong> žinutė',
    'Reply now' => 'Atsakyti dabar',
];
