<?php

return [
    '<strong>New</strong> message' => '<strong>Nova</strong> poruka',
    'Reply now' => 'Odgovori sada',
];
