<?php
return array (
  '<strong>New</strong> message' => '<strong>Nova</strong> poruka',
  'Add recipients' => 'Dodaj primatelje',
  'Send' => 'Pošalji',
);
