<?php

return [
    'Send' => 'Trimite',
    '<strong>New</strong> message' => '',
    'Add recipients' => '',
];
