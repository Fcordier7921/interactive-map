<?php
return array (
  'Only visible for space admins' => 'Vidljivo samo za svemirske administratore',
  'Open in new window' => 'Otvori u novom prozoru',
);
