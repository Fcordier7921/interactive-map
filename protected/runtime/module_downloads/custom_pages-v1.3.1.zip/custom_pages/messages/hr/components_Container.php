<?php
return array (
  'Content' => 'Sadržaj',
  'ID' => 'ID',
  'Icon' => '',
  'Invalid template selection!' => '',
  'Invalid view file selection!' => '',
  'Sort Order' => 'Redoslijed',
  'Style Class' => '',
  'Target Url' => '',
  'Template Layout' => '',
  'Title' => 'Naziv',
  'Type' => 'Vrsta',
);
