<?php
return array (
  'Snippet' => 'Isječak',
  'snippet' => 'isječak',
);
