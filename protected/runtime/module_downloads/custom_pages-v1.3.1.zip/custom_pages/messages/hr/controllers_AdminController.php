<?php
return array (
  '<strong>Add</strong> {templateName} item' => '<strong>Dodaj</strong> {templateName} stavku',
  '<strong>Edit</strong> item' => '<strong>Uredi</strong> stavku',
);
