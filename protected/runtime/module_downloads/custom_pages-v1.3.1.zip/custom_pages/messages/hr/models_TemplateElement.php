<?php
return array (
  'Label' => 'Obilješka',
  'Placeholder name' => 'Naziv rezerviranog mjesta',
  'The element name must contain at least two characters without spaces or special signs except \'_\'' => 'Naziv elementa mora sadržavati najmanje dva znaka bez razmaka ili posebnih znakova, osim \'_\'',
  'The given element name is already in use for this template.' => 'Dati naziv elementa već se koristi za ovaj predložak.',
);
