<?php
return array (
  'Admin only' => 'Samo za administratora',
  'All Members' => 'Svi članovi',
  'Members & Guests' => 'Članovi i gosti',
  'Members only' => 'Samo za članove',
  'Public' => 'Javno',
  'Space Members only' => 'Samo članovi prostora',
);
