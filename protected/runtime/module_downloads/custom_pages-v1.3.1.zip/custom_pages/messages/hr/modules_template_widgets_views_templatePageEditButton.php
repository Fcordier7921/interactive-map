<?php
return array (
  'Edit Page' => 'Uredi stranicu',
);
