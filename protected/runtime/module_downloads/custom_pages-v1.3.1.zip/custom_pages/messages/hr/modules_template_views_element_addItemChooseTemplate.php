<?php
return array (
  'Choose a template' => 'Odaberite predložak',
  'Template' => 'Predložak',
);
