<?php
return array (
  'Url' => 'URL',
  'View' => 'Vidi',
);
