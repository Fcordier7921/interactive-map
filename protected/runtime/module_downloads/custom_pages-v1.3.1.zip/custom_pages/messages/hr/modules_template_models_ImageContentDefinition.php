<?php
return array (
  'Height' => 'Visina',
  'Style' => 'Stil',
  'Width' => 'Širina',
);
