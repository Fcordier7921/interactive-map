<?php
return array (
  'Empty Image' => 'Prazna slika',
);
