<?php
return array (
  'Open page...' => 'Otvori stranicu...',
);
