<?php
return array (
  'Empty' => 'Prazno',
  'Inline' => 'U redu',
  'Multiple' => 'Višestruko',
  'This template does not contain any elements yet.' => 'Ovaj predložak još ne sadrži nijedan element.',
);
