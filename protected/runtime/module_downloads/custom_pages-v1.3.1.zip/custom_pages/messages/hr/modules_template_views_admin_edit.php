<?php
return array (
  'Create new {type}' => 'Kreiraj novi/u {type}',
  'Edit template \'{templateName}\'' => 'Uredi predložak \'{templateName}\'',
  'Save' => 'Spremi',
);
