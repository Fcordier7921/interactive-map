<?php
return array (
  'Use default content' => 'Koristite zadani sadržaj',
);
