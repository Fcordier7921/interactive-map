<?php
return array (
  'Display Empty Content' => 'Prikaži prazan sadržaj',
  'Update' => 'Ažuriranje',
);
