<?php
return array (
  'Allow multiple items?' => 'Dopustiti više stavki?',
  'Allowed Templates' => 'Dopušteni predlošci',
  'Render items as inline-blocks within the inline editor?' => 'Renderirati stavke kao umetnute blokove u umetnutom uređivaču?',
);
