<?php
return array (
  'Empty <br />Container' => 'Prazan<br> spremnik',
);
