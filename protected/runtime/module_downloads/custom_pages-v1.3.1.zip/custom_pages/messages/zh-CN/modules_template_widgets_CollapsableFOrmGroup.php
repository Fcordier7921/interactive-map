<?php
return array (
  'Show less' => '展示更少',
  'Show more' => '展示更多',
);
