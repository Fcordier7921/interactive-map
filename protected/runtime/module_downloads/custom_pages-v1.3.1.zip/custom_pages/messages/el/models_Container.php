<?php
return array (
  'Empty <br />Container' => 'Κενό <br /> Container',
);
