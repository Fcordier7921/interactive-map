<?php
return array (
  'Admin only' => '',
  'All Members' => '',
  'Members & Guests' => '',
  'Members only' => '',
  'Public' => 'Δημόσιο',
  'Space Members only' => '',
);
