<?php
return array (
  'Empty Image' => 'Κενή εικόνα',
);
