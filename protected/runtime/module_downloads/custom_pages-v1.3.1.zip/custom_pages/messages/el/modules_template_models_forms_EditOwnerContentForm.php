<?php
return array (
  'Use default content' => 'Χρησιμοποιήστε προεπιλεγμένο περιεχόμενο',
);
