<?php
return array (
  'Here you can manage your snipped layouts. Snippet layouts are templates, which can be included into sidebars.' => 'Εδώ μπορείτε να διαχειριστείτε τις απεικονιζόμενες διατάξεις σας. Οι διατάξεις διαμόρφωσης αποσπασμάτων είναι πρότυπα, τα οποία μπορούν να συμπεριληφθούν στις πλευρικές γραμμές.',
);
