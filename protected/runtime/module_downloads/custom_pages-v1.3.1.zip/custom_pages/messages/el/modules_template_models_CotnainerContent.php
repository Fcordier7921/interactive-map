<?php
return array (
  'Allow multiple items?' => 'Να επιτρέπονται πολλαπλά στοιχεία;',
  'Allowed Templates' => 'Επιτρεπόμενα πρότυπα',
  'Render items as inline-blocks within the inline editor?' => 'Αντικαταστήστε τα στοιχεία ως ενσωματωμένα μπλοκ μέσα στον ενσωματωμένο επεξεργαστή;',
);
