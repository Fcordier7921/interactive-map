<?php
return array (
  'Snippet' => 'Απόσπασμα',
  'snippet' => 'απόσπασμα',
);
