<?php
return array (
  'none' => 'τίποτα',
);
