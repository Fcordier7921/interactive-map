<?php
return array (
  'Display Empty Content' => 'Προβολή κενού περιεχομένου',
  'Update' => 'Ενημέρωση',
);
