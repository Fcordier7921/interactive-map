<?php
return array (
  'Url' => '',
  'View' => 'Θέα',
);
