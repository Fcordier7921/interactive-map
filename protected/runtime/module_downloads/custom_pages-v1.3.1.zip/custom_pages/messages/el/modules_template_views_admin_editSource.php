<?php
return array (
  'Add Element' => 'Προσθήκη στοιχείου',
  'Edit All' => 'Επεξεργασία όλων',
  'Edit template \'{templateName}\'' => 'Επεξεργασία προτύπου \'{templateName}\'',
  'Here you can edit the source of your template by defining the template layout and adding content elements. Each element can be assigned with a default content and additional definitions.' => 'Εδώ μπορείτε να επεξεργαστείτε την προέλευση του προτύπου σας καθορίζοντας τη διάταξη του προτύπου και προσθέτοντας στοιχεία περιεχομένου. Κάθε στοιχείο μπορεί να αντιστοιχιστεί με προεπιλεγμένο περιεχόμενο και πρόσθετους ορισμούς.',
  'You haven\'t saved your last changes yet. Do you want to leave without saving?' => 'Δεν έχετε αποθηκεύσει ακόμη τις τελευταίες αλλαγές σας. Θέλετε να φύγετε χωρίς αποθήκευση;',
);
