<?php
return array (
  '<strong>Add</strong> new {type} element' => '<strong>Προσθήκη</strong> νέου {type} στοιχείου',
  '<strong>Edit</strong> element {name}' => '<strong>Επεξεργασία</strong> στοιχείου {name}',
  '<strong>Edit</strong> elements of {templateName}' => '<strong>Επεξεργασία</strong> στοιχείων του {templateName}',
  '<strong>Edit</strong> {templateName}' => '<strong>Επεξεργασία</strong> {templateName}',
  'Template not found!' => 'Το πρότυπο δεν βρέθηκε!',
  'The template could not be deleted, please get sure that this template is not in use.' => 'Το πρότυπο δεν μπορεί να διαγραφεί, παρακαλούμε βεβαιωθείτε ότι αυτό το πρότυπο δεν είναι σε χρήση.',
);
