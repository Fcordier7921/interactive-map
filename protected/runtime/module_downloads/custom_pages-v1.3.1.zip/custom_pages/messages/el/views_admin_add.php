<?php
return array (
  'Add new {pageType}' => 'Προσθήκη νέου {pageType}',
  'Create new template' => 'Δημιουργία νέου προτύπου',
  'Edit template' => 'Επεξεργασία προτύπου',
  'Settings' => 'Ρυθμίσεις',
);
