<?php

return [
    'Empty Richtext' => 'Κενό εμπλουτισμένο',
    'Empty Text' => 'Κενό κείμενο',
    'Empty HumHub Richtext' => '',
];
