<?php
return array (
  'Are you sure you want to delete this container item?' => 'Είστε σίγουροι ότι θέλετε να διαγράψετε το στοιχείο δοχείου;',
  'Do you really want to delete this content?' => 'Θέλετε πραγματικά να διαγράψετε αυτό το περιεχόμενο;',
  'Do you really want to delete this element? <br />The deletion will affect all pages using this template.' => 'Θέλετε πραγματικά να διαγράψετε αυτό το στοιχείο; <br /> Η διαγραφή θα επηρεάσει όλες τις σελίδες που χρησιμοποιούν αυτό το πρότυπο',
);
