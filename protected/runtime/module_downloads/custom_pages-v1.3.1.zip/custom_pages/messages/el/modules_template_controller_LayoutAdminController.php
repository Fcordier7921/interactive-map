<?php
return array (
  'Here you can manage your template layouts. Layouts are the root of your template pages and can not be combined with other templates.' => 'Εδώ μπορείτε να διαχειριστείτε τις διατάξεις προτύπων. Οι διατάξεις είναι η ρίζα των σελίδων προτύπων και δεν μπορούν να συνδυαστούν με άλλα πρότυπα.',
);
