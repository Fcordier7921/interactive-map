<?php
return array (
  'Content' => 'Περιεχόμενο',
  'Sidebar' => 'Πλευρική μπάρα',
  'snippet' => 'απόσπασμα',
);
