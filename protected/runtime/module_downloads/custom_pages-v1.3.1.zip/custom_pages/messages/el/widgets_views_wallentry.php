<?php
return array (
  'Open page...' => 'Άνοιγμα σελίδας ...',
);
