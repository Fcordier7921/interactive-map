<?php
return array (
  'Show less' => 'Προβολή λιγότερων',
  'Show more' => 'Προβολή περισσότερων',
);
