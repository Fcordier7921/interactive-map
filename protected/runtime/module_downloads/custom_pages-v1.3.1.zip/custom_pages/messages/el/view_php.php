<?php
return array (
  'View not found' => 'Η προβολή δεν βρέθηκε',
);
