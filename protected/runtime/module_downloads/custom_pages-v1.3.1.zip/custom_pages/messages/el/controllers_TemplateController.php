<?php
return array (
  '<strong>Edit</strong> {type} element' => '<strong>Επεξεργασία</strong> στοιχείου {type}',
  'Access denied!' => 'Η πρόσβαση απορρίφθηκε!',
  'Empty content elements cannot be delted!' => 'Τα κενά στοιχεία περιεχομένου δεν μπορούν να διαγραφούν!',
  'Invalid request data!' => 'Μη έγκυρη αίτηση δεδομένων!',
  'You are not allowed to delete default content!' => 'Δεν επιτρέπεται η διαγραφή του προεπιλεγμένου περιεχομένου!',
);
