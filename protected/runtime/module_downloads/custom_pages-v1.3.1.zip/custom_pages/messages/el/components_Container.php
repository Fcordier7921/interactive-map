<?php
return array (
  'Content' => 'Περιεχόμενο',
  'ID' => 'ID',
  'Icon' => 'Εικονίδιο',
  'Invalid template selection!' => 'Μη έγκυρη επιλογή προτύπου!',
  'Invalid view file selection!' => 'Μη έγκυρη προβολή επιλεγμένου αρχείου!',
  'Sort Order' => 'Σειρά ταξινόμησης',
  'Style Class' => 'Κατηγορία στυλ',
  'Target Url' => 'Στοχευμένει Url',
  'Template Layout' => 'Διάταξη προτύπου',
  'Title' => 'Τίτλος',
  'Type' => 'Τύπος',
);
