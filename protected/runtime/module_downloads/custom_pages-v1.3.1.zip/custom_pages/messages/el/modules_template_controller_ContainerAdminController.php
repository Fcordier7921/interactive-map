<?php
return array (
  'Here you can manage your template container elements.' => 'Εδώ μπορείτε να διαχειριστείτε τα στοιχεία του δοχείου προτύπου.',
);
