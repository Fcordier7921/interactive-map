<?php
return array (
  'less' => 'Λιγότερο',
  'more' => 'Περισσότερο',
);
