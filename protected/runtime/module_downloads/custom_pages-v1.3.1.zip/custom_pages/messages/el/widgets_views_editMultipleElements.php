<?php
return array (
  'Empty' => 'Κενό',
  'Inline' => 'Ενσωματωμένο',
  'Multiple' => 'Πολλαπλό',
  'This template does not contain any elements yet.' => 'Αυτό το πρότυπο δεν περιέχει στοιχεία ακόμη.',
);
