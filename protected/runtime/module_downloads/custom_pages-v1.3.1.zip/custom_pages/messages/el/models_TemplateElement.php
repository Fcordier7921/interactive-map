<?php
return array (
  'Label' => 'Επιγραφή',
  'Placeholder name' => 'Όνομα Χωροθέτη',
  'The element name must contain at least two characters without spaces or special signs except \'_\'' => 'Το όνομα του στοιχείου πρέπει να περιέχει τουλάχιστον δύο χαρακτήρες χωρίς κενά ή ειδικά σύμβολα, εκτός από το \'_\'',
  'The given element name is already in use for this template.' => 'Το δοσμένο όνομα στοιχείου χρησιμοποιείται ήδη για αυτό το πρότυπο.',
);
