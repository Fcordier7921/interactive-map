<?php
return array (
  'Use empty content' => 'Χρησιμοποιήστε κενό περιεχόμενο',
);
