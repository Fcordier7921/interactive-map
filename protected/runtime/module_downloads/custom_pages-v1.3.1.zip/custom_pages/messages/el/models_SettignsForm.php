<?php
return array (
  'Activate PHP based Pages and Snippets' => 'Ενεργοποιήστε σελίδες και αποσπάσματα που βασίζονται στην PHP',
  'If disabled, existing php pages will still be online, but can\'t be created.' => 'Αν απενεργοποιηθεί, οι υπάρχουσες σελίδες php θα εξακολουθούν να είναι Σε συνδεδεμένες, αλλά δεν μπορούν να δημιουργηθούν.',
  'PHP view path for custom space pages' => 'Διαδρομή προβολής PHP για σελίδες προσαρμοσμένου χώρου',
  'PHP view path for custom space snippets' => 'Διαδρομή προβολής PHP για αποσπάσματα προσαρμοσμένου χώρου',
  'PHP view path for global custom pages' => 'Διαδρομή προβολής PHP για παγκόσμιες προσαρμοσμένες σελίδες',
  'PHP view path for global custom snippets' => 'Διαδρομή προβολής PHP για παγκόσμια προσαρμοσμένα αποσπάσματα',
  'The given view file path does not exist.' => 'Η δοσμένη διαδρομή προβολής αρχείου δεν υπάρχει.',
);
