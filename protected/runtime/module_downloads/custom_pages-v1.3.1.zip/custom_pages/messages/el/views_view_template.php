<?php
return array (
  'Edit Template' => 'Επεξεργασία Προτύπου',
  'Edit elements' => 'Επεξεργασία στοιχείων',
  'Edit template' => 'Επεξεργασία προτύπου',
  'Page configuration' => 'Διαμόρφωση σελίδας',
  'Turn edit off' => 'Απενεργοποιήστε την επεξεργασία',
);
