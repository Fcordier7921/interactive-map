<?php
return array (
  'Edit Page' => 'Επεξεργασία σελίδας',
);
