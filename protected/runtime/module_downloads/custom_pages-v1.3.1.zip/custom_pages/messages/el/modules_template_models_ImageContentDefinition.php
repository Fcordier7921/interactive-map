<?php
return array (
  'Height' => 'Ύψος',
  'Style' => 'Στυλ',
  'Width' => 'Πλάτος',
);
