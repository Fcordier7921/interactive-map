<?php
return array (
  '<strong>Confirm</strong> container item deletion' => '<strong>Επιβεβαίωση</strong> διαγραφής στοιχείου δοχείου',
  '<strong>Confirm</strong> content deletion' => '<strong>Επιβεβαίωση</strong>διαγραφής περιεχομένου',
  '<strong>Confirm</strong> element deletion' => '<strong>Επιβεβαίωση</strong> διαγραφής στοιχείου',
);
