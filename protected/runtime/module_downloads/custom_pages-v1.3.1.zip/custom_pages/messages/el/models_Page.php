<?php

return [
    'Navigation' => 'Πλοήγηση',
    'Only visible for admins' => 'Ορατό μόνο για διαχειριστές',
    'Open in new window' => 'Άνοιγμα σε νέο παράθυρο',
    'Url shortcut' => 'συντόμευση Url',
    'View' => 'Θέα',
    'page' => 'Σελίδα',
    'Abstract' => '',
    'Page' => '',
];
