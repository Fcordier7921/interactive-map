<?php
return array (
  'Create new {type}' => 'Δημιουργία νέου {type}',
  'Edit template \'{templateName}\'' => 'Επεξεργασία προτύπου \'{templateName}\'',
  'Save' => 'Αποθήκευση',
);
