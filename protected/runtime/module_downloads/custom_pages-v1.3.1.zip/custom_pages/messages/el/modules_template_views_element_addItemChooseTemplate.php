<?php
return array (
  'Choose a template' => 'Επιλέξτε πρότυπο',
  'Template' => 'Πρότυπο',
);
