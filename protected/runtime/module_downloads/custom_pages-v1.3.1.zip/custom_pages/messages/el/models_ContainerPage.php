<?php

return [
    'Only visible for space admins' => 'Εμφανίζεται μόνο για διαχειριστές χώρων',
    'Open in new window' => 'Άνοιγμα σε νέο παράθυρο',
];
