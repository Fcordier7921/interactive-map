<?php
return array (
  '<strong>Add</strong> {templateName} item' => '<strong>Προσθήκη</strong> στοιχείου {templateName}',
  '<strong>Edit</strong> item' => '<strong>Επεξεργασία</strong> στοιχείου',
);
