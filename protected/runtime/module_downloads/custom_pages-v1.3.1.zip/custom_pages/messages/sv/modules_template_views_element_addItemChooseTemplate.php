<?php
return array (
  'Choose a template' => '',
  'Template' => 'Mall',
);
