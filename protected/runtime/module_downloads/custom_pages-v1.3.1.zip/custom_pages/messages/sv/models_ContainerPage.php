<?php

return [
    'Open in new window' => 'Öppna i nytt fönster',
    'Only visible for space admins' => '',
];
