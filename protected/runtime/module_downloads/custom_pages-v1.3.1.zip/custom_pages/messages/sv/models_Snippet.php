<?php
return array (
  'Content' => 'Innehåll',
  'Sidebar' => '',
  'snippet' => '',
);
