<?php
return array (
  'Height' => 'Höjd',
  'Style' => 'Stil',
  'Width' => 'Bredd',
);
