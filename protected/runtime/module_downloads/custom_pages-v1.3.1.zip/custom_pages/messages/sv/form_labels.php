<?php
return array (
  'Url' => '',
  'View' => 'Visa',
);
