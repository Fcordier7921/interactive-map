<?php
return array (
  'Content' => 'Innehåll',
  'ID' => 'ID',
  'Icon' => '',
  'Invalid template selection!' => '',
  'Invalid view file selection!' => '',
  'Sort Order' => 'Sorteringsordning',
  'Style Class' => '',
  'Target Url' => '',
  'Template Layout' => '',
  'Title' => 'Titel',
  'Type' => 'Typ',
);
