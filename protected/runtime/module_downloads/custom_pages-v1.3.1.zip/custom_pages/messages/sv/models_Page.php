<?php

return [
    'Navigation' => 'Navigation',
    'Only visible for admins' => 'Endast synligt för admin',
    'Open in new window' => 'Öppna i nytt fönster',
    'View' => 'Visa',
    'page' => 'sida',
    'Abstract' => '',
    'Page' => '',
    'Url shortcut' => '',
];
