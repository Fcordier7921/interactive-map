<?php
return array (
  'Empty' => 'Tom',
  'Inline' => '',
  'Multiple' => '',
  'This template does not contain any elements yet.' => '',
);
