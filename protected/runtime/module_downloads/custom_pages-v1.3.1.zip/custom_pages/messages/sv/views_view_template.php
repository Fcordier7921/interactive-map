<?php
return array (
  'Edit Template' => 'Redigera Mall',
  'Edit elements' => '',
  'Edit template' => 'Redigera Mall',
  'Page configuration' => '',
  'Turn edit off' => '',
);
