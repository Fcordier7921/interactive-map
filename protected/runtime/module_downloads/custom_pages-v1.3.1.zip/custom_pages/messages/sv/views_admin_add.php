<?php
return array (
  'Add new {pageType}' => 'Lägg till ny {pageType}',
  'Create new template' => 'Skapa ny mall',
  'Edit template' => 'Redigera mall',
  'Settings' => 'Inställningar',
);
