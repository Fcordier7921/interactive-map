<?php
return array (
  'Create new {type}' => 'Skapa ny {type}',
  'Edit template \'{templateName}\'' => '',
  'Save' => 'Spara',
);
