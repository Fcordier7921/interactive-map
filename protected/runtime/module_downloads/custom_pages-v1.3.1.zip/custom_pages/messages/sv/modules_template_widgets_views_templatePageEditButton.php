<?php
return array (
  'Edit Page' => 'Ändra sida',
);
