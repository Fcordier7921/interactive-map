<?php
return array (
  'Show less' => 'Arată mai puțin',
  'Show more' => 'Arata mai mult',
);
