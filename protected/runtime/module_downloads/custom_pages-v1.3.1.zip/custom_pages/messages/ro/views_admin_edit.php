<?php
return array (
  'Save' => 'Salvează',
);
