<?php
return array (
  'Height' => 'Înălțime',
  'Style' => '',
  'Width' => 'Lățime',
);
