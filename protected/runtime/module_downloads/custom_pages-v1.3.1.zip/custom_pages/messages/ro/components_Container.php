<?php
return array (
  'Content' => 'Conținut',
  'ID' => 'ID',
  'Icon' => '',
  'Invalid template selection!' => '',
  'Invalid view file selection!' => '',
  'Sort Order' => '',
  'Style Class' => '',
  'Target Url' => '',
  'Template Layout' => '',
  'Title' => 'Titlul',
  'Type' => 'Tip',
);
