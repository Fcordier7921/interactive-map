<?php
return array (
  'Content' => 'Conținut',
  'Sidebar' => '',
  'snippet' => '',
);
