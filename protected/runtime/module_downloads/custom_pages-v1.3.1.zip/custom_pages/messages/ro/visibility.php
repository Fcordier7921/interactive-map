<?php
return array (
  'Admin only' => '',
  'All Members' => '',
  'Members & Guests' => '',
  'Members only' => '',
  'Public' => 'Public',
  'Space Members only' => '',
);
