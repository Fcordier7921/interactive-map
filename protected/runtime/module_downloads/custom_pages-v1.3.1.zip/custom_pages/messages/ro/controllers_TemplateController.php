<?php
return array (
  '<strong>Edit</strong> {type} element' => '',
  'Access denied!' => 'Acces respins!',
  'Empty content elements cannot be delted!' => '',
  'Invalid request data!' => '',
  'You are not allowed to delete default content!' => '',
);
