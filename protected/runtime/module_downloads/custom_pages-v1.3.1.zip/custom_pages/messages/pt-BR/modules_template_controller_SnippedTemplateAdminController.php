<?php
return array (
  'Here you can manage your snipped layouts. Snippet layouts are templates, which can be included into sidebars.' => 'Aqui você pode gerenciar seus layouts recortados. Layouts de trechos são modelos, que podem ser incluídos em barras laterais.',
);
