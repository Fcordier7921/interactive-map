<?php
return array (
  'Are you sure you want to delete this container item?' => 'Tem certeza de que deseja excluir este item de contêiner?',
  'Do you really want to delete this content?' => 'Você realmente quer deletar este conteúdo?',
  'Do you really want to delete this element? <br />The deletion will affect all pages using this template.' => 'Você realmente quer apagar este elemento? <br /> A exclusão afetará todas as páginas usando este modelo.',
);
