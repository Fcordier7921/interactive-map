<?php
return array (
  'Here you can manage your template container elements.' => 'Aqui você pode gerenciar seus elementos de contêiner de modelo.',
);
