<?php
return array (
  'Choose a template' => 'Selecione um modelo',
  'Template' => 'Modelo',
);
