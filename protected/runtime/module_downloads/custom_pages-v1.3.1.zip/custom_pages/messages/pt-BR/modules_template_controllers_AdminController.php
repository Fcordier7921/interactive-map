<?php
return array (
  '<strong>Add</strong> new {type} element' => '<strong>Adicionar</strong> novo elemento {type}',
  '<strong>Edit</strong> element {name}' => '<strong>Editar</strong> elemento{nome}
',
  '<strong>Edit</strong> elements of {templateName}' => '<strong>Editar</strong> elementos de {templateName}',
  '<strong>Edit</strong> {templateName}' => '<strong>Editar</strong> {templateName}',
  'Template not found!' => 'Modelo não encontrado!',
  'The template could not be deleted, please get sure that this template is not in use.' => 'O modelo não pode ser excluído. Verifique se esse modelo não está em uso.',
);
