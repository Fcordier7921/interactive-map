<?php
return array (
  'Content' => 'Conteúdo',
  'Sidebar' => 'Barra Lateral',
  'snippet' => 'trecho',
);
