<?php
return array (
  'Show less' => 'Mostre menos',
  'Show more' => 'Mostre mais',
);
