<?php
return array (
  'Use empty content' => 'Use conteúdo vazio',
);
