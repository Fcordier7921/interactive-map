<?php

return [
    'Empty Richtext' => 'Richtext vazio',
    'Empty Text' => 'Texto vazio',
    'Empty HumHub Richtext' => '',
];
