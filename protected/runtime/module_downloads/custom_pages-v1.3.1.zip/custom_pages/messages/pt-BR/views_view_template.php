<?php
return array (
  'Edit Template' => 'Editar modelo',
  'Edit elements' => 'Editar elementos',
  'Edit template' => 'Editar modelo',
  'Page configuration' => 'Configuração de página',
  'Turn edit off' => 'Desligue a edição',
);
