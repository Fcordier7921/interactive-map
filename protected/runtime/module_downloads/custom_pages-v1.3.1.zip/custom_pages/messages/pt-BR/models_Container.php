<?php
return array (
  'Empty <br />Container' => 'Recipiente  <br /> Vazio ',
);
