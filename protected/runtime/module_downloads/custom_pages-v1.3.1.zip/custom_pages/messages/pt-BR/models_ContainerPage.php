<?php

return [
    'Only visible for space admins' => 'Visível apenas para administradores de espaço',
    'Open in new window' => 'Abrir em uma nova janela',
];
