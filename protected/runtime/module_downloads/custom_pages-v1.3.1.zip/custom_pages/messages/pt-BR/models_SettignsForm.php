<?php
return array (
  'Activate PHP based Pages and Snippets' => 'Ativar páginas e snippets baseados em PHP',
  'If disabled, existing php pages will still be online, but can\'t be created.' => 'Se desativado, as páginas php existentes ainda estarão on-line, mas não podem ser criadas.',
  'PHP view path for custom space pages' => 'Caminho de visualização do PHP para páginas de espaço personalizadas',
  'PHP view path for custom space snippets' => 'Caminho de visualização do PHP para fragmentos de espaço personalizados',
  'PHP view path for global custom pages' => 'Caminho de visualização do PHP para páginas customizadas globais',
  'PHP view path for global custom snippets' => 'Caminho de visualização do PHP para fragmentos personalizados globais',
  'The given view file path does not exist.' => 'O caminho do arquivo de visualização fornecido não existe.',
);
