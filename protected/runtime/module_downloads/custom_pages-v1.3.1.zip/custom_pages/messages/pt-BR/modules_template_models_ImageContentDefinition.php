<?php
return array (
  'Height' => 'Altura',
  'Style' => 'Estilo',
  'Width' => 'Largura',
);
