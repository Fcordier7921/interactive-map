<?php
return array (
  'Url' => 'Url',
  'View' => 'Visualizar',
);
