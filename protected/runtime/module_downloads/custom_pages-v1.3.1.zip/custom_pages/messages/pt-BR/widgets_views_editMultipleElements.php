<?php
return array (
  'Empty' => 'Vazio',
  'Inline' => 'Na linha',
  'Multiple' => 'Mútiplo',
  'This template does not contain any elements yet.' => 'Este modelo não contém elementos ainda.',
);
