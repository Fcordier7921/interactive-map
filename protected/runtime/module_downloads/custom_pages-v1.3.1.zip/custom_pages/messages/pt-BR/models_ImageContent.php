<?php
return array (
  'Empty Image' => 'Imagem vazia',
);
