<?php
return array (
  'Display Empty Content' => 'Exibir conteúdo vazio',
  'Update' => 'Atualizar',
);
