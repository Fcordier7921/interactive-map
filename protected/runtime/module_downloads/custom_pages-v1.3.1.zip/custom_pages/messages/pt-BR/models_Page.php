<?php

return [
    'Navigation' => 'Navegação',
    'Only visible for admins' => 'Visível apenas para administradores',
    'Open in new window' => 'Abrir em uma nova janela',
    'Url shortcut' => 'Atalho de URL',
    'View' => 'Visualizar',
    'page' => 'página',
    'Abstract' => '',
    'Page' => '',
];
