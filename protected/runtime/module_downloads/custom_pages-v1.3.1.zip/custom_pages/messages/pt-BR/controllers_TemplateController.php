<?php
return array (
  '<strong>Edit</strong> {type} element' => '<strong>Editar</strong> {type} elemento',
  'Access denied!' => 'Acesso negado',
  'Empty content elements cannot be delted!' => 'Elementos de conteúdo vazios não podem ser eliminados!',
  'Invalid request data!' => 'Dados de solicitação inválidos!',
  'You are not allowed to delete default content!' => 'Você não tem permissão para excluir conteúdo padrão!',
);
