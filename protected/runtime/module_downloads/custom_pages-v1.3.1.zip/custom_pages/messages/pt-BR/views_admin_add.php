<?php
return array (
  'Add new {pageType}' => 'Adicionar novo {pageType}',
  'Create new template' => 'Criar novo modelo',
  'Edit template' => 'Editar modelo',
  'Settings' => 'Configurações',
);
