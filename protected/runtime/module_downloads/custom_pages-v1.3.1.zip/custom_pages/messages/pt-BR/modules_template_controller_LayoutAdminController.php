<?php
return array (
  'Here you can manage your template layouts. Layouts are the root of your template pages and can not be combined with other templates.' => 'Aqui você pode gerenciar seus layouts de modelo. Os layouts são a raiz das suas páginas de modelo e não podem ser combinados com outros modelos.',
);
