<?php
return array (
  'Label' => 'Rótulo',
  'Placeholder name' => 'Nome do espaço reservado',
  'The element name must contain at least two characters without spaces or special signs except \'_\'' => 'O nome do elemento deve conter pelo menos dois caracteres sem espaços ou sinais especiais, exceto \'_\'',
  'The given element name is already in use for this template.' => 'O nome do elemento especificado já está em uso para este modelo.',
);
