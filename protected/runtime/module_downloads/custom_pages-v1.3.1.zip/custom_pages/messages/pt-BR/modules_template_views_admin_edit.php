<?php
return array (
  'Create new {type}' => 'Criar novo {type}',
  'Edit template \'{templateName}\'' => 'Editar modelo \'{templateName}\'',
  'Save' => 'Salvar',
);
