<?php
return array (
  '<strong>Add</strong> {templateName} item' => '<strong> Adicionar</strong> {templateName} Item',
  '<strong>Edit</strong> item' => '<strong>Editar</strong> item',
);
