<?php
return array (
  'Edit Page' => 'Editar página',
);
