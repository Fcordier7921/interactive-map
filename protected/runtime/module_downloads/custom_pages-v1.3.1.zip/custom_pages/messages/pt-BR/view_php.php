<?php
return array (
  'View not found' => 'Visualização não ecnontrada',
);
