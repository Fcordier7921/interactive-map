<?php
return array (
  'Use default content' => 'Use o conteúdo padrão',
);
