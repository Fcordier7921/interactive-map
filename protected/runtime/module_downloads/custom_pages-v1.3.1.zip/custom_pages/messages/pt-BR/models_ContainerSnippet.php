<?php
return array (
  'Snippet' => 'Fragmento',
  'snippet' => 'trecho',
);
