<?php
return array (
  'Content' => 'Conteúdo',
  'ID' => 'ID',
  'Icon' => 'ìcone',
  'Invalid template selection!' => 'Seleção de modelo inválida!',
  'Invalid view file selection!' => 'Seleção de arquivo de visualização inválida!',
  'Sort Order' => 'Ordem de classificação',
  'Style Class' => 'Classe de Estilo',
  'Target Url' => 'URL Alvo',
  'Template Layout' => 'Layout de modelo',
  'Title' => 'Título',
  'Type' => 'Tipo',
);
