<?php
return array (
  'none' => 'Nenhum',
);
