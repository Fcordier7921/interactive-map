<?php
return array (
  'less' => 'menos',
  'more' => 'mais',
);
