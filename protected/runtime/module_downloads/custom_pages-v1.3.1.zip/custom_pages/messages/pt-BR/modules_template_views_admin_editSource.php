<?php
return array (
  'Add Element' => 'Adicionar elemento',
  'Edit All' => 'Editar todos',
  'Edit template \'{templateName}\'' => 'Editar modelo \'{templateName}\'',
  'Here you can edit the source of your template by defining the template layout and adding content elements. Each element can be assigned with a default content and additional definitions.' => 'Aqui você pode editar a origem do seu modelo definindo o layout do modelo e adicionando elementos de conteúdo. Cada elemento pode ser atribuído com um conteúdo padrão e definições adicionais.',
  'You haven\'t saved your last changes yet. Do you want to leave without saving?' => 'Você ainda não salvou suas últimas alterações. Você quer sair sem salvar?',
);
