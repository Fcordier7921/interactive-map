<?php
return array (
  'Allow multiple items?' => 'Permitir vários itens?',
  'Allowed Templates' => 'Modelos permitidos',
  'Render items as inline-blocks within the inline editor?' => 'Renderizar itens como blocos embutidos dentro do editor embutido?',
);
