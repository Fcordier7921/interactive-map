<?php
return array (
  '<strong>Confirm</strong> container item deletion' => '<strong>Confirmar</strong> exclusão de item de contêiner
',
  '<strong>Confirm</strong> content deletion' => '<strong>Confirme a exclusão de conteúdo</strong>',
  '<strong>Confirm</strong> element deletion' => '<strong>Confirme a exclusão do elemento</strong>',
);
