<?php
return array (
  'Show less' => 'Показать меньше',
  'Show more' => 'Показать больше',
);
