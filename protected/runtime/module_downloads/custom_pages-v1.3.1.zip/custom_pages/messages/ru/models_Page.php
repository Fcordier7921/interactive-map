<?php

return [
    'Navigation' => 'Навигация',
    'View' => 'Просмотр',
    'Abstract' => '',
    'Only visible for admins' => '',
    'Open in new window' => '',
    'Page' => '',
    'Url shortcut' => '',
    'page' => '',
];
