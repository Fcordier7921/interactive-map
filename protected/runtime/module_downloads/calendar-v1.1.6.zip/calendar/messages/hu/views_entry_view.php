<?php
return array (
  'Additional information' => 'További információ',
  'Attend' => 'Részt vesz',
  'Decline' => 'Nem vesz részt',
  'Maybe' => 'Talán',
);
