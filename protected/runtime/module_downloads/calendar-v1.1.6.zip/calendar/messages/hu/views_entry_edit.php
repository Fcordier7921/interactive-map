<?php
return array (
  '<strong>Create</strong> event' => 'Esemény <strong>létrehozása</strong>',
  '<strong>Edit</strong> event' => 'Esemény <strong>szerkesztése</strong>',
  '<strong>Edit</strong> recurring event' => 'Ismétlődő esemény <strong>szerkesztése</strong>',
  'Basic' => 'Alap',
  'Everybody can participate' => 'Bárki részt vehet',
  'Files' => 'Fájlok',
  'No participants' => 'Nincsenek résztvevők',
  'Participation' => 'Részvétel',
  'Recurrence' => 'Ismétlődés',
  'Reminder' => 'Emlékeztető',
  'Select event type...' => 'Eseménytípus kiválasztása...',
  'Title' => 'Cím',
);
