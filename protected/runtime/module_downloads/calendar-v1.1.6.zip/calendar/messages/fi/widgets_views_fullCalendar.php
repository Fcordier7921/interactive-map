<?php
return array (
  'Loading...' => 'Ladataan...',
);
