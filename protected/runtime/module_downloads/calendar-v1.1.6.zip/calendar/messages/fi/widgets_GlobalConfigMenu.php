<?php

return [
    'Defaults' => 'Oletukset',
    'Event Types' => 'Taphtumatyypit',
    'Snippet' => 'Laatikko',
    'Calendars' => '',
];
