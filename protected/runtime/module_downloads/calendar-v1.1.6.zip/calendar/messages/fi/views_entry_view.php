<?php

return [
    'Attend' => 'Osallistu',
    'Decline' => 'En osallistu',
    'Maybe' => 'Ehkä osalistun',
    'Additional information' => '',
];
