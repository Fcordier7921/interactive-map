<?php
return array (
  '{displayName} canceled event "{contentTitle}" in space {spaceName}.' => '{displayName} perui tapahtuman "{contentTitle}" sivulla {spaceName}.',
  '{displayName} canceled event "{contentTitle}".' => '{displayName} peruutti tapahtuman "{contentTitle}".',
  '{displayName} just added you to event "{contentTitle}".' => '{displayName} lisäsi sinut juuri tapahtumaan "{contentTitle}"',
  '{displayName} just updated event "{contentTitle}" in space {spaceName}.' => '{displayName} päivitti tapahtumaa "{contentTitle}" sivulla {spaceName}.',
  '{displayName} just updated event {contentTitle}.' => '{displayName} juuri päivitti tapahtumaa {contentTitle}.',
  '{displayName} reopened event "{contentTitle}" in space {spaceName}.' => '{displayName} avasi uudelleen tapahtuman "{contentTitle}" sivulla {spaceName}.',
  '{displayName} reopened event "{contentTitle}".' => '{displayName} avasi uudestaan tapahtuman "{contentTitle}".',
);
