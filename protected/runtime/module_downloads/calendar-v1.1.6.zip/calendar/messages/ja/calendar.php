<?php
return array (
  'day' => '',
  'list' => '',
  'month' => '',
  'today' => '今日',
  'week' => '',
);
