<?php
return array (
  'Calendar' => 'カレンダー',
  'Receive Calendar related Notifications.' => '',
);
