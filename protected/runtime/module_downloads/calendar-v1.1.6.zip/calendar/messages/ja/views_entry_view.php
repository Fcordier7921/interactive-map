<?php

return [
    'Attend' => '参加',
    'Decline' => '辞退',
    'Maybe' => '未定',
    'Additional information' => '',
];
