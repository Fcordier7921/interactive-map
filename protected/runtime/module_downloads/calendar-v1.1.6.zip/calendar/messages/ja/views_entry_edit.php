<?php

return [
    '<strong>Create</strong> event' => '<strong>作成</strong> イベントの作成',
    '<strong>Edit</strong> event' => '<strong>編集</strong> イベントの編集',
    'Basic' => '基本',
    'Everybody can participate' => '誰もが参加できる',
    'Files' => 'ファイル',
    'No participants' => '参加しない',
    'Title' => 'タイトル',
    '<strong>Edit</strong> recurring event' => '',
    'Participation' => '',
    'Recurrence' => '',
    'Reminder' => '',
    'Select event type...' => '',
];
