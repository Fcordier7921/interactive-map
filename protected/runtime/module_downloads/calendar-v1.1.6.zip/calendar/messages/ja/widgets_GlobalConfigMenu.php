<?php

return [
    'Defaults' => '既定',
    'Calendars' => '',
    'Event Types' => '',
    'Snippet' => '',
];
