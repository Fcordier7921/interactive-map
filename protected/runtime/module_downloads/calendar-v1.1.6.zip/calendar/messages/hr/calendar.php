<?php
return array (
  'day' => 'dan',
  'list' => 'lista',
  'month' => 'mjesec',
  'today' => 'danas',
  'week' => 'tjedan',
);
