<?php
return array (
  'Calendars' => 'Kalendari',
  'Defaults' => 'Zadano',
  'Event Types' => 'Vrste događaja',
  'Snippet' => 'Isječak',
);
