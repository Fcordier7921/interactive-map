<?php
return array (
  'Calendar' => 'Calendari',
  'Receive Calendar related Notifications.' => '',
);
