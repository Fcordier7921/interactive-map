<?php
return array (
  '<strong>Create</strong> new event type' => '<strong>Crea</strong> un nuovo tipo di evento',
  '<strong>Edit</strong> calendar' => '<strong>Modifica</strong> calendario',
  '<strong>Edit</strong> event type' => '<strong>Modifica</strong> il tipo di evento',
);
