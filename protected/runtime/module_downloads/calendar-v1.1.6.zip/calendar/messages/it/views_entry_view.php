<?php

return [
    'Attend' => 'Partecipa',
    'Decline' => 'Rifiuta',
    'Maybe' => 'Forse',
    'Additional information' => '',
];
