<?php
return array (
  '%displayName% created a new %contentTitle%.' => '%displayName% ha creato un nuovo %contentTitle%.',
);
