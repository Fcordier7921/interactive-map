<?php
return array (
  'Allows the user to create new calendar entries' => 'Permetti all\' utente di creare nuove voci del calendario',
  'Allows the user to edit/delete existing calendar entries' => 'Consente all\' utente di modificare/eliminare le voci del calendario esistenti',
  'Create entry' => 'Crea voce',
  'Manage entries' => 'Gestione delle voci',
);
