<?php
return array (
  '<strong>Starting</strong> {date}' => '<strong>Inizio</strong> {date}',
  'Additional information:' => 'Informazioni aggiuntive',
  'Location:' => 'Luogo:',
  'Organized by {userName}' => 'Organizzato da {userName}',
  'View Online: {url}' => 'Visualizza online: {url}',
);
