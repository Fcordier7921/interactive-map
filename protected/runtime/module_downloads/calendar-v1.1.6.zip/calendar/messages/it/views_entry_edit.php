<?php
return array (
  '<strong>Create</strong> event' => '<strong>Crea</strong> evento',
  '<strong>Edit</strong> event' => '<strong>Modifica</strong> evento',
  '<strong>Edit</strong> recurring event' => '<strong>Modifica</strong> evento ricorrente',
  'Basic' => 'Base',
  'Everybody can participate' => 'Ognuno può partecipare',
  'Files' => 'Files',
  'No participants' => 'Nessun partecipante',
  'Participation' => 'Partecipazione',
  'Recurrence' => 'Ricorrenza',
  'Reminder' => 'Promemoria',
  'Select event type...' => 'Seleziona il tipo di evento....',
  'Title' => 'Titolo',
);
