<?php

return [
    'Defaults' => 'Standarder',
    'Calendars' => '',
    'Event Types' => '',
    'Snippet' => '',
];
