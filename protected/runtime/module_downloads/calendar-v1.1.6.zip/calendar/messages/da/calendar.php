<?php
return array (
  'day' => '',
  'list' => 'Liste',
  'month' => '',
  'today' => 'i dag',
  'week' => '',
);
