<?php

return [
    'Attend' => 'Deltag',
    'Decline' => 'Afslå',
    'Maybe' => 'Måske',
    'Additional information' => '',
];
