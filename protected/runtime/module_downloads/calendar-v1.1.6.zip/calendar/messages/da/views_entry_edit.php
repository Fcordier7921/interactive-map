<?php

return [
    '<strong>Create</strong> event' => '<strong>Opret</strong> event',
    '<strong>Edit</strong> event' => '<strong>Rediger</strong> event',
    'Basic' => 'Basis',
    'Everybody can participate' => 'Alle kan deltage',
    'Files' => 'Filer',
    'No participants' => 'Ingen deltagere',
    'Title' => 'Titel',
    '<strong>Edit</strong> recurring event' => '',
    'Participation' => '',
    'Recurrence' => '',
    'Reminder' => '',
    'Select event type...' => '',
];
