<?php
return array (
  'day' => '',
  'list' => '',
  'month' => '',
  'today' => 'šiandien',
  'week' => '',
);
