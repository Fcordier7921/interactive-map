<?php
return array (
  '<strong>Upcoming</strong> events ' => '<strong>Événement(s)</strong> à venir',
  'Open Calendar' => 'Ouvrir le calendrier',
);
