<?php
return array (
  '<strong>Starting</strong> {date}' => '<strong>Début</strong> {date}',
  'Additional information:' => 'Informations additionnelles :',
  'Location:' => 'Lieu :',
  'Organized by {userName}' => 'Organisé par {userName}',
  'View Online: {url}' => 'Voir en ligne : {url}',
);
