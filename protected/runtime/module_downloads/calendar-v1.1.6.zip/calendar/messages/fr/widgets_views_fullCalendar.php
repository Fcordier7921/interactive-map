<?php
return array (
  'Loading...' => 'Chargement...',
);
