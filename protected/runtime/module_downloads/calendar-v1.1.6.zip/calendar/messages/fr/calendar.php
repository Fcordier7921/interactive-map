<?php
return array (
  'day' => 'jour',
  'list' => 'liste',
  'month' => 'mois',
  'today' => 'aujourd\'hui',
  'week' => 'semaine',
);
