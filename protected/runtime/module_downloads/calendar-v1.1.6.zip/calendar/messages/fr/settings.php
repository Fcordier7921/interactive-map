<?php
return array (
  'Participation' => 'Participation',
  'Reminder' => 'Rappel',
);
