<?php
return array (
  'Participation' => 'Συμμετοχή',
  'Reminder' => 'Υπενθύμιση',
);
