<?php
return array (
  '<strong>Create</strong> event' => '<strong>Δημιουργία</strong> Εκδήλωσης',
  '<strong>Edit</strong> event' => '<strong>Επεξεργασία </strong> Εκδήλωσης',
  '<strong>Edit</strong> recurring event' => '',
  'Basic' => 'Βασικό',
  'Everybody can participate' => 'Ο καθένας μπορεί να συμμετάσχει',
  'Files' => 'Αρχεία',
  'No participants' => 'Δεν υπάρχουν συμμετέχοντες',
  'Participation' => 'Συμμετοχή',
  'Recurrence' => '',
  'Reminder' => 'Υπενθύμιση',
  'Select event type...' => 'Επιλέξτε τύπο εκδήλωσης ...',
  'Title' => 'Τίτλος',
);
