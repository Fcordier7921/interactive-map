<?php

return [
    ':count attending' => ': αριθμός συμμετεχόντων',
    ':count declined' => ': αριθμός ακυρωμένων',
    ':count maybe' => ': αριθμός ίσως',
    'Participants' => '',
];
