<?php
return array (
  '<strong>Upcoming</strong> events ' => '<strong>Ανερχόμενη</strong> εκδήλωση',
  'Open Calendar' => 'Άνοιγμα ημερολογίου',
);
