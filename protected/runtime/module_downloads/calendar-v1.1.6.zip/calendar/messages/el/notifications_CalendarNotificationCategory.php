<?php
return array (
  'Calendar' => 'Ημερολόγιο',
  'Receive Calendar related Notifications.' => 'Λήψη ειδοποιήσεων σχετικών με το ημερολόγιο.',
);
