<?php
return array (
  ':count attending' => ':count присъстващи',
  ':count declined' => ':count отказали',
  ':count maybe' => ':count не са сигурни',
  'Participants' => 'Участници',
);
