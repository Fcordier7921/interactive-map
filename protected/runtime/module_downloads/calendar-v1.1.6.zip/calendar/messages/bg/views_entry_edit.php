<?php
return array (
  '<strong>Create</strong> event' => '<strong>Създаване</strong> на събитие',
  '<strong>Edit</strong> event' => '<strong>Редактиране</strong> на събитие',
  '<strong>Edit</strong> recurring event' => '<strong>Редактиране</strong> на повтарящо се събитие',
  'Basic' => 'Основен',
  'Everybody can participate' => 'Всеки може да участва',
  'Files' => 'Файлове',
  'No participants' => 'Няма участници',
  'Participation' => 'Участие',
  'Recurrence' => 'Повтаряне',
  'Reminder' => 'Напомняне',
  'Select event type...' => 'Изберете тип събитие...',
  'Title' => 'Заглавие',
);
