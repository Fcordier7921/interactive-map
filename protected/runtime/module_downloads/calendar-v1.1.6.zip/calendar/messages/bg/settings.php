<?php
return array (
  'Participation' => 'Участие',
  'Reminder' => 'Напомняне',
);
