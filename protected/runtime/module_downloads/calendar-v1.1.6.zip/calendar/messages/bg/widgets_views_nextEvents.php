<?php
return array (
  '<strong>Upcoming</strong> events ' => '<strong>Предстоящи</strong> събития',
  'Open Calendar' => 'Отворете Календар',
);
