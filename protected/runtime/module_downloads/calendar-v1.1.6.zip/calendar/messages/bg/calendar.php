<?php
return array (
  'day' => 'ден',
  'list' => 'списък',
  'month' => 'месец',
  'today' => 'днес',
  'week' => 'седмица',
);
