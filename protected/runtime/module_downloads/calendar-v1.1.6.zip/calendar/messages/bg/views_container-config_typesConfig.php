<?php
return array (
  '<strong>Create</strong> new event type' => '<strong>Създайте</strong> нов тип събитие',
  '<strong>Edit</strong> calendar' => '<strong>Редактиране</strong> на календар',
  '<strong>Edit</strong> event type' => '<strong>Редактиране</strong> на тип събитие',
);
