<?php
return array (
  'Additional information' => 'Допълнителна информация',
  'Attend' => 'Присъствам',
  'Decline' => 'Отказвам',
  'Maybe' => 'Не съм сигурен',
);
