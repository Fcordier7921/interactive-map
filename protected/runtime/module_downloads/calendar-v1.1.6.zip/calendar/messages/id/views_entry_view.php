<?php

return [
    'Attend' => 'Hadir',
    'Decline' => 'Batal',
    'Maybe' => 'Mungkin',
    'Additional information' => '',
];
