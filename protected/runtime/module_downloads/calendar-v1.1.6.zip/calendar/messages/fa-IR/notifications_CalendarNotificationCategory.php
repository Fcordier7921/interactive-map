<?php
return array (
  'Calendar' => 'تقویم',
  'Receive Calendar related Notifications.' => '',
);
