<?php
return array (
  '%displayName% created a new %contentTitle%.' => '%contentTitle% %displayName% را تولید کرد.',
);
