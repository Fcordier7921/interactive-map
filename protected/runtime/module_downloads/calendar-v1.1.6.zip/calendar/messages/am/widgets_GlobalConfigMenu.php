<?php

return [
    'Calendars' => '',
    'Defaults' => '',
    'Event Types' => '',
    'Snippet' => '',
];
