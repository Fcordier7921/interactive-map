<?php

return [
    'Custom reminder' => '',
    'Day' => '',
    'Default reminder settings' => '',
    'Here you can configure default settings for all calendar events.' => '',
    'Here you can configure global default reminders. These settings can be overwritten on space/profile level.' => '',
    'Here you can configure the default reminder settings for this event. Users are able to overwrite these settings by means of the
        <strong>Set reminder</strong> link.' => '',
    'Hour' => '',
    'No reminder' => '',
    'Upcoming {type}' => '',
    'Upcoming {type}: {title}' => '',
    'Use default reminder' => '',
    'Week' => '',
    'You have an <strong>{type}</strong> coming up' => '',
    'You have an <strong>{type}</strong> coming up: {title}' => '',
    'Your reminder settings for event: <strong>\'{title}\'</strong>' => '',
];
