<?php

return [
    'Basic' => 'መሰረታዊ',
    'Files' => 'ፋይሎች',
    'Title' => 'ርዕስ',
    '<strong>Create</strong> event' => '',
    '<strong>Edit</strong> event' => '',
    '<strong>Edit</strong> recurring event' => '',
    'Everybody can participate' => '',
    'No participants' => '',
    'Participation' => '',
    'Recurrence' => '',
    'Reminder' => '',
    'Select event type...' => '',
];
