<?php

return [
    'Participation' => '',
    'Reminder' => '',
];
