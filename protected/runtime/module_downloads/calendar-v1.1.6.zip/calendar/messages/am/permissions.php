<?php

return [
    'Allows the user to create new calendar entries' => '',
    'Allows the user to edit/delete existing calendar entries' => '',
    'Create entry' => '',
    'Manage entries' => '',
];
