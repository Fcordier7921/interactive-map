<?php

return [
    'Calendar' => '',
    'Receive Calendar related Notifications.' => '',
];
