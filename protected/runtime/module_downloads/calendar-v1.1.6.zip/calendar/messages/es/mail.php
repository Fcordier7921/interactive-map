<?php
return array (
  '<strong>Starting</strong> {date}' => '<strong>Empezando</strong> {date}',
  'Additional information:' => 'Información adicional:',
  'Location:' => 'Locación:',
  'Organized by {userName}' => 'Organizado por {userName}',
  'View Online: {url}' => 'Ver en línea: {url}',
);
