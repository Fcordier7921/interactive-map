<?php
return array (
  '<strong>Upcoming</strong> events ' => 'Eventos <strong>próximos</strong>',
  'Open Calendar' => 'Calendario abierto',
);
