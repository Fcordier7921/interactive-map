<?php
return array (
  'Additional information' => 'Información Adicional',
  'Attend' => 'Asistir',
  'Decline' => 'No asistir',
  'Maybe' => 'Tal vez',
);
