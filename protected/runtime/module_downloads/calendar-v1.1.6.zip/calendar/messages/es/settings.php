<?php
return array (
  'Participation' => 'Participación',
  'Reminder' => 'Recordatorio',
);
