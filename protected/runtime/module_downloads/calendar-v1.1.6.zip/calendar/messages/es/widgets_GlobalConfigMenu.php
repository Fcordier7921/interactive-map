<?php
return array (
  'Calendars' => 'Calendarios',
  'Defaults' => 'Valores por defecto',
  'Event Types' => 'Tipos de evento',
  'Snippet' => 'Snippet',
);
