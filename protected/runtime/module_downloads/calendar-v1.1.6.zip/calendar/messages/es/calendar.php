<?php
return array (
  'day' => 'día',
  'list' => 'lista',
  'month' => 'mes',
  'today' => 'hoy',
  'week' => 'semana',
);
