<?php
return array (
  'Allows the user to create new calendar entries' => 'Erlaubt dem Benutzer, neue Kalendereinträge zu erstellen.',
  'Allows the user to edit/delete existing calendar entries' => 'Erlaubt dem Benutzer, bestehende Kalendereinträge zu bearbeiten/löschen.',
  'Create entry' => 'Kalendereinträge erstellen',
  'Manage entries' => 'Kalendereinträge verwalten',
);
