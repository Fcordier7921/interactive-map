<?php
return array (
  'Participation' => 'Teilnahmemodus',
  'Reminder' => 'Erinnerung',
);
