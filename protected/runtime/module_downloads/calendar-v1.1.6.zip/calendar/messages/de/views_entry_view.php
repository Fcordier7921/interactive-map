<?php
return array (
  'Additional information' => 'Weitere Informationen',
  'Attend' => 'Annehmen',
  'Decline' => 'Ablehnen',
  'Maybe' => 'Vielleicht',
);
