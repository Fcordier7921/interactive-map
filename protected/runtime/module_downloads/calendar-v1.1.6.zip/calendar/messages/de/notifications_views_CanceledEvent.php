<?php
return array (
  '{displayName} canceled event "{contentTitle}" in space {spaceName}.' => '{displayName} hat den Termin "{contentTitle}" im Space {spaceName} abgesagt.',
  '{displayName} canceled event "{contentTitle}".' => '{displayName} hat den Termin "{contentTitle}" abgesagt.',
  '{displayName} just added you to event "{contentTitle}".' => '{displayName} hat dich gerade zu Termin "{contentTitle}" hinzugefügt.',
  '{displayName} just updated event "{contentTitle}" in space {spaceName}.' => '{displayName} hat "{contentTitle}" im Space {spaceName} aktualisiert.',
  '{displayName} just updated event {contentTitle}.' => '{displayName} hat Termin "{contentTitle}" aktualisiert.',
  '{displayName} reopened event "{contentTitle}" in space {spaceName}.' => '{displayName} hat den Termin "{contentTitle}" im Space {spaceName} wieder eröffnet.',
  '{displayName} reopened event "{contentTitle}".' => '{displayName} hat den Termin "{contentTitle}" wieder eröffnet.',
);
