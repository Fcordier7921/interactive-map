<?php

return [
    'Defaults' => 'Výchozí',
    'Calendars' => '',
    'Event Types' => '',
    'Snippet' => '',
];
