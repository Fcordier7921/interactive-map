<?php

return [
    'Attend' => 'Chci se zúčastnit',
    'Decline' => 'Nechci se zúčastnit',
    'Maybe' => 'Možná',
    'Additional information' => '',
];
