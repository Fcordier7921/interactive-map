<?php
return array (
  'day' => '',
  'list' => 'seznam',
  'month' => '',
  'today' => 'dnes',
  'week' => '',
);
