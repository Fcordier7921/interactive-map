<?php

return [
    '<strong>Create</strong> event' => '<strong>Vytvořit</strong> událost',
    '<strong>Edit</strong> event' => '<strong>Upravit</strong> událost',
    'Basic' => 'Základní',
    'Everybody can participate' => 'Každý se může zúčastnit',
    'Files' => 'Soubory',
    'No participants' => 'Nikdo se nemůže zúčastnit',
    'Title' => 'Nadpis',
    '<strong>Edit</strong> recurring event' => '',
    'Participation' => '',
    'Recurrence' => '',
    'Reminder' => '',
    'Select event type...' => '',
];
