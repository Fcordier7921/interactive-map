<?php
return array (
  'Calendar' => 'Kalendář',
  'Receive Calendar related Notifications.' => '',
);
