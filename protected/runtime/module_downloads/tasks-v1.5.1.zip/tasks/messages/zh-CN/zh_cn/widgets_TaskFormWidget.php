<?php
return array (
  'Create' => '创建',
);
