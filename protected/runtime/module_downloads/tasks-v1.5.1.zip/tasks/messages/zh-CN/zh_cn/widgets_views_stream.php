<?php
return array (
  '<b>There are no tasks yet!</b>' => '',
  'Back to stream' => '@@返回动态@@',
  'No tasks found which matches your current filter(s)!' => '@@没有符合条件的记录!@@',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '<b>还没有任务!</b><br>创建第一个任务...',
  'Assigned to me' => '分配给我的',
  'Created by me' => '我创建的',
  'Creation time' => '创建时间',
  'Filter' => '筛选',
  'Last update' => '最后更新',
  'Nobody assigned' => '未指定人',
  'Sorting' => '排序',
  'State is finished' => '已完成状态',
  'State is open' => '打开状态',
);
