<?php
return array (
  'Already requested' => '',
  'Request sent' => '',
  'You have insufficient permissions to perform that operation!' => '您没有足够的权限执行这个操作!',
);
