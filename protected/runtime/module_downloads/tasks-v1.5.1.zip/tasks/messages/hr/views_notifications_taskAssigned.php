<?php
return array (
  '{userName} assigned you to the task {task}.' => '{userName} dodijelio vas je zadatku {task}.',
);
