<?php
return array (
  '<b>There are no tasks yet!</b>' => '<b>Još nema zadataka!</b>',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '<b>Još nema zadataka!</b><br>Budite prvi i kreirajte jedan...',
  'Assigned to me' => 'Dodijeljeno meni',
  'Created by me' => 'Kreirao sam',
  'Creation time' => 'Vrjeme kreiranja',
  'Filter' => 'Filter',
  'Last update' => 'Zadnje ažuriranje',
  'Nobody assigned' => 'Nitko nije dodijeljen',
  'Sorting' => 'Sortiranje',
  'State is finished' => 'Status je završen',
  'State is open' => 'Status je otvoren',
);
