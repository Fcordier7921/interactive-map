<?php
return array (
  'Allows the user to create, delete and edit tasks and lists and also sort tasks and lists' => 'Omogućuje korisniku stvaranje, brisanje i uređivanje zadataka i popisa te sortiranje zadataka i popisa',
  'Allows the user to process unassigned tasks' => 'Omogućuje korisniku obradu neraspoređenih zadataka',
  'Manage tasks' => 'Upravljanje zadacima',
  'Process unassigned tasks' => 'Obradite neraspoređene zadatke',
);
