<?php
return array (
  '{userName} completed task {task}.' => '{userName} je završio/la zadatak {task}.',
  '{userName} reset task {task}.' => '{userName} resetira zadatak {task}.',
  '{userName} reviewed task {task}.' => '{userName} je pregledao/la zadatak {task}.',
  '{userName} works on task {task}.' => '{userName} radi na zadatku {task}.',
);
