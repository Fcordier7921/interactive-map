<?php
return array (
  'Anyone can work on this task!' => 'Svatko može raditi na ovom zadatku!',
  'Open Task' => 'Otvorite zadatak',
  'This task can only be processed by assigned and responsible users.' => 'Ovaj zadatak mogu obraditi samo dodijeljeni i odgovorni korisnici.',
);
