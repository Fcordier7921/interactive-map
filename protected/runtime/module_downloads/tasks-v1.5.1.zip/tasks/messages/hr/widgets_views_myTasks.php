<?php
return array (
  '<strong>Your</strong> tasks' => '<strong>Vaši</strong> zadaci',
);
