<?php
return array (
  '{userName} assigned you as responsible person in task {task} from space {spaceName}.' => 'Korisnik {userName} dodijelio vas je kao odgovornu osobu u zadatku {task} iz prostora {spaceName}.',
);
