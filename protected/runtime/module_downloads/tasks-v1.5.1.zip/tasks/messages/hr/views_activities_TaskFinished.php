<?php
return array (
  '{userName} finished task {task}.' => '{userName} završio je zadatak {task}.',
);
