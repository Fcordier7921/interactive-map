<?php
return array (
  '{userName} created task {task}.' => '{userName} kreirao je zadatak {task}.',
);
