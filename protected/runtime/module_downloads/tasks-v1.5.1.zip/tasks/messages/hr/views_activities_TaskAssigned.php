<?php
return array (
  '{userName} assigned to task {task}.' => '{userName} dodijeljen je zadatku {task}.',
);
