<?php
return array (
  '<strong>Task</strong> module configuration' => '',
  'Displays a global task menu item on the main menu.' => '',
  'Global task menu item' => '',
  'Max tasks items' => '',
  'Menu Item sort order' => '',
  'Show global task menu item' => '',
  'Show snippet' => 'Prikaži isječak',
  'Show snippet in Space' => '',
  'Shows a widget with tasks on the dashboard where you are assigned/responsible.' => '',
  'Shows the widget also on the dashboard of spaces.' => '',
  'Sort order' => 'Sortiranje',
  'Your tasks snippet' => '',
);
