<?php
return array (
  'Receive Notifications for Task Reminder.' => '',
  'Receive Notifications for Tasks (Deadline Updates, Status changes ...).' => '',
  'Reminder' => 'Påminnelse',
  'Task {task} in space {spaceName} ends at {dateTime}.' => '',
  'Task {task} in space {spaceName} starts at {dateTime}.' => '',
  'View Online' => 'Se online',
  '{userName} assigned you to task {task} in space {spaceName}.' => '',
  '{userName} completed Task {task} in space {spaceName}.' => '',
  '{userName} has changed deadline for task {task} in space {spaceName}.' => '',
  '{userName} has re-opened task {task} in space {spaceName}.' => '',
  '{userName} has rejected task {task} in space {spaceName} as incomplete.' => '',
  '{userName} marked Task {task} in space {spaceName} as completed.' => '',
  '{userName} requests a deadline extension for task {task} in space {spaceName}.' => '',
  '{userName} requests you to review Task {task} in space {spaceName}.' => '',
  '{userName} started working on Task {task} in space {spaceName}.' => '',
);
