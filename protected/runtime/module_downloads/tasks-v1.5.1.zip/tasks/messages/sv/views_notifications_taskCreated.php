<?php
return array (
  '{userName} created a new task {task}.' => '{userName} skapade en ny uppgift {task}.',
);
