<?php
return array (
  'Completed' => 'Avslutad',
  'Title' => 'Rubrik',
);
