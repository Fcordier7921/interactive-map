<?php
return array (
  '<strong>Create</strong> new task' => '<strong>Skapa</strong> ny uppgift',
  '<strong>Edit</strong> task' => '<strong>Ändra</strong> uppgift',
  'Assign users' => 'Tilldela användare',
  'Cancel' => 'Avbryt',
  'Deadline' => 'Stopptid',
  'Save' => 'Spara',
  'What is to do?' => 'Vad göra?',
);
