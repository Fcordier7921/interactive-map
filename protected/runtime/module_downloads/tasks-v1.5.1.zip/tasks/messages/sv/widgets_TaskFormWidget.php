<?php
return array (
  'Create' => 'Skapa',
);
