<?php
return array (
  'End Date' => 'Slutdatum',
  'End Time' => 'Sluttid',
  'End time must be after start time!' => 'Sluttid måste vara efter starttid!',
  'Public' => 'Publik',
  'Start Date' => 'Startdatum',
  'Start Time' => 'Starttid',
  'Time Zone' => 'Tidszon',
);
