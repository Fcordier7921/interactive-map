<?php
return array (
  '1 Day before' => '1 Dag innan',
  '1 Month before' => '1 Månad innan',
  '1 Week before' => '1 Vecka innan',
  '2 Days before' => '2 Dagar innan',
  '2 Weeks before' => '2 Veckor innan',
  '3 Weeks before' => '3 Veckor innan',
  'At least 1 Hour before' => '',
  'At least 2 Hours before' => '',
  'Do not remind' => 'Påminn inte',
  'Remind Mode' => 'Påminnelse läge',
  'Task' => 'Uppgift',
);
