<?php
return array (
  'Assign users to this task' => 'Tilldela uppgiften till användare',
  'Deadline for this task?' => 'När skall uppgiften vara klar?',
  'Preassign user(s) for this task.' => 'Förvälj användare till denna uppgift.',
  'What to do?' => 'Att göra?',
);
