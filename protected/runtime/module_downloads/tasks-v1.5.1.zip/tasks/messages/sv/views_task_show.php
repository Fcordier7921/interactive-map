<?php
return array (
  '<strong>Confirm</strong> deleting' => '<strong>Bekräfta</strong> radering',
  'Add Task' => 'Lägg till uppgift',
  'Cancel' => 'Avbryt',
  'Delete' => 'Ta bort',
  'Do you really want to delete this task?' => 'Vill du verkligen radera denna uppgift?',
  'No open tasks...' => 'Inga öppna uppgifter...',
  'completed tasks' => 'Klara uppgifter',
);
