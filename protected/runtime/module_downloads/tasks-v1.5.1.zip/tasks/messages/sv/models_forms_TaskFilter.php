<?php
return array (
  'Created by me' => 'Skapad av mig',
  'End date' => '',
  'Filter status' => '',
  'Filter tasks' => '',
  'I\'m assigned' => '',
  'I\'m responsible' => '',
  'Overdue' => '',
  'Spaces' => 'Nätverk ',
  'Start date' => '',
  'Status' => 'Status',
  'Title' => 'Titel',
);
