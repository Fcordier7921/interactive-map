<?php
return array (
  '<b>There are no tasks yet!</b>' => '<b>Det finns inga uppgifter ännu!</b>',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '<b>There are no tasks yet!</b> Bli den första att skapa...',
  'Assigned to me' => 'Tilldelade mig',
  'Back to stream' => '@@@@',
  'Created by me' => 'Skapade av mig',
  'Creation time' => 'Skapad',
  'Filter' => 'Filtrera',
  'Last update' => 'Senast uppdaterad',
  'No tasks found which matches your current filter(s)!' => '@@@@',
  'Nobody assigned' => 'Ingen tilldelad',
  'Sorting' => 'Sortering',
  'State is finished' => 'Avslutad',
  'State is open' => 'Pågående',
);
