<?php

return [
    'Anyone can work on this task!' => '',
    'Open Task' => '',
    'This task can only be processed by assigned and responsible users.' => '',
];
