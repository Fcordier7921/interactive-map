<?php
return array (
  'Could not access task!' => 'Kunde inte komma åt uppgiften!',
);
