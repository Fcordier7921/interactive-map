<?php
return array (
  'End Date' => 'Data Scadentă',
  'End Time' => 'Sfarsit',
  'End time must be after start time!' => 'Timpul scadent trebuie să fie după timpul de început!',
  'Public' => 'Public',
  'Start Date' => 'Data Începerii',
  'Start Time' => 'Inceput',
  'Time Zone' => 'Timp Zonal',
);
