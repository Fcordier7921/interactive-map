<?php
return array (
  'Created by me' => 'Creat de mine',
  'End date' => '',
  'Filter status' => '',
  'Filter tasks' => '',
  'I\'m assigned' => '',
  'I\'m responsible' => '',
  'Overdue' => '',
  'Spaces' => 'Spatii',
  'Start date' => '',
  'Status' => '',
  'Title' => 'Titlul',
);
