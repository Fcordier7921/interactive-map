<?php
return array (
  'Completed' => '',
  'Title' => 'Titlul',
);
