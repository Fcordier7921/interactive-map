<?php
return array (
  '{userName} created a new task {task}.' => '',
);
