<?php
return array (
  'Already requested' => '',
  'Request sent' => '',
  'You have insufficient permissions to perform that operation!' => 'Вы должны иметь доступ на выполнение этой операции!',
);
