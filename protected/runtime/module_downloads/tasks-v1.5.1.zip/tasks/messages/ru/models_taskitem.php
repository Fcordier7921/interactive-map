<?php
return array (
  'Completed' => '',
  'Title' => 'Заголовок',
);
