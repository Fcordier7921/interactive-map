<?php

return [
    'End Date' => '',
    'End Time' => '',
    'End time must be after start time!' => '',
    'Public' => '',
    'Start Date' => '',
    'Start Time' => '',
    'Time Zone' => '',
];
