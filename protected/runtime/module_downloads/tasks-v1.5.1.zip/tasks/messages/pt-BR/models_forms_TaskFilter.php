<?php
return array (
  'Created by me' => 'Criado por mim',
  'End date' => 'Data final',
  'Filter status' => 'Status do filtro',
  'Filter tasks' => 'Filtrar tarefas',
  'I\'m assigned' => 'Estou designado',
  'I\'m responsible' => 'eu sou responsável',
  'Overdue' => 'Vencidas',
  'Spaces' => 'Espaços',
  'Start date' => 'Data de início',
  'Status' => 'Status',
  'Title' => 'Título',
);
