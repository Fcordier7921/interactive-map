<?php
return array (
  'Already requested' => '',
  'Request sent' => '',
  'You have insufficient permissions to perform that operation!' => 'Você não tem permissões suficientes para executar essa operação!',
);
