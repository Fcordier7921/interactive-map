<?php
return array (
  '<strong>Task</strong> module configuration' => '',
  'Max tasks items' => '',
  'Show snippet' => '',
  'Show snippet in Space' => '',
  'Shows a widget with tasks on the dashboard where you are assigned/responsible.' => '',
  'Shows the widget also on the dashboard of spaces.' => '',
  'Sort order' => 'ترتیب مرتب‌سازی',
  'Your tasks snippet' => '',
);
