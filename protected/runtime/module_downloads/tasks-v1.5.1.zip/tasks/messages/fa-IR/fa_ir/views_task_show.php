<?php
return array (
  '<strong>Confirm</strong> deleting' => '<strong>تاييد حذف</strong>',
  'Add Task' => 'ايجاد وظيفه',
  'Cancel' => 'لغو',
  'Delete' => 'حذف',
  'Do you really want to delete this task?' => 'وظيفه حذف شود؟',
  'No open tasks...' => 'هيچ وظيف بازي نيست',
  'completed tasks' => 'وظايف به اتمام رسيده',
);
