<?php
return array (
  '<strong>Create</strong> new task' => '<strong>ايجاد مظيفه جديد</strong>',
  '<strong>Edit</strong> task' => '<strong>ويرايش وظيفه</strong>',
  'Assign users' => 'اختصاص كاربر',
  'Cancel' => 'لغو',
  'Deadline' => 'مهلت',
  'Save' => 'ذخيره',
  'What is to do?' => 'ملزم به انجام چه چيزي است؟',
);
