<?php
return array (
  'Created by me' => 'Δημιουργήθηκε από εμένα',
  'End date' => '',
  'Filter status' => '',
  'Filter tasks' => '',
  'I\'m assigned' => '',
  'I\'m responsible' => '',
  'Overdue' => '',
  'Spaces' => 'Χώροι',
  'Start date' => '',
  'Status' => '',
  'Title' => 'Τίτλος',
);
