<?php
return array (
  'Allows the user to create, delete and edit tasks and lists and also sort tasks and lists' => 'Permite al usuario crear, eliminar y editar tareas y listas, como también ordenar tareas y listas.',
  'Allows the user to process unassigned tasks' => 'Permitir a los usuarios trabajar en tareas con usuarios sin asignar',
  'Manage tasks' => 'Organizar tareas',
  'Process unassigned tasks' => 'Procesar tareas sin asignar',
);
