<?php
return array (
  'Drag list' => 'Arrastrar lista',
);
