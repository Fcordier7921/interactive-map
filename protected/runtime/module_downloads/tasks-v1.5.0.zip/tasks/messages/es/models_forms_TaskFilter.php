<?php
return array (
  'Created by me' => 'Creada por mí',
  'End date' => 'Fecha de término',
  'Filter status' => 'Filtrar estatus',
  'Filter tasks' => 'Filtrar tareas',
  'I\'m assigned' => 'Estoy asignado',
  'I\'m responsible' => 'Soy responsable',
  'Overdue' => 'Atrasado',
  'Spaces' => 'Espacios',
  'Start date' => 'Fecha de inicio',
  'Status' => 'Estado',
  'Title' => 'Título',
);
