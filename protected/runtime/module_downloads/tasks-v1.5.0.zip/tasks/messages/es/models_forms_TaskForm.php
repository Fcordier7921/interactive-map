<?php
return array (
  'End Date' => 'Fecha de fin',
  'End Time' => 'Hora Final',
  'End time must be after start time!' => '¡La fecha de fin tiene que ser después de la fecha de inicio!',
  'Public' => 'Público',
  'Start Date' => 'Fecha de inicio',
  'Start Time' => 'Hora de Inicio',
  'Time Zone' => 'Zona horaria',
);
