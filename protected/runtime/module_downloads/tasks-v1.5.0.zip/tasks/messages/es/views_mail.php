<?php
return array (
  'Your Reminder for task {task}' => 'Tu recordatorio para la tarea {task}',
);
