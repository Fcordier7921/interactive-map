<?php
return array (
  '1 Day before' => '1 día antes',
  '1 Month before' => '1 mes antes',
  '1 Week before' => '1 semana antes',
  '2 Days before' => '2 días antes',
  '2 Weeks before' => '2 semanas antes',
  '3 Weeks before' => '3 semanas antes',
  'At least 1 Hour before' => 'Al menos 1 hora antes',
  'At least 2 Hours before' => 'Al menos 2 horas antes',
  'Do not remind' => 'No recordar',
  'Remind Mode' => 'Modo de recordatorio',
  'Task' => 'Tarea',
);
