<?php
return array (
  '<strong>Task</strong> module configuration' => 'Configuración del módulo<strong>Tareas</strong>',
  'Displays a global task menu item on the main menu.' => 'Mostrar un ítem de menú de tareas globales en el menú principal.',
  'Global task menu item' => 'Ítem de menú para tarea global',
  'Max tasks items' => 'Máximo de ítems de tareas.',
  'Menu Item sort order' => 'Orden del menú de ítems',
  'Show global task menu item' => 'Mostrar un menú de ítems para tareas globales',
  'Show snippet' => 'Mostrar snippet',
  'Show snippet in Space' => 'Mostrar fragmento en espacio',
  'Shows a widget with tasks on the dashboard where you are assigned/responsible.' => 'Mostrar un widget en el inicio con las <strong>tareas</strong> las cuales has sido asignado como responsable.',
  'Shows the widget also on the dashboard of spaces.' => 'Mostrar el widget también en el inicio de los espacios.',
  'Sort order' => 'Ordenado por',
  'Your tasks snippet' => 'Tus fragmentos de tareas.',
);
