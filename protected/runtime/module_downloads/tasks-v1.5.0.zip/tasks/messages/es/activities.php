<?php

return [
    '{userName} completed task {task}.' => '{userName} completó la tarea {task}.',
    '{userName} reset task {task}.' => '{userName} restauró la tarea {task}.',
    '{userName} reviewed task {task}.' => '{userName} revisó la tarea {task}.',
    '{userName} works on task {task}.' => '{userName} está trabajando en la tarea {task}.',
];
