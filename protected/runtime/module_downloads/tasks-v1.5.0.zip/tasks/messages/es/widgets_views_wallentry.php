<?php
return array (
  'Anyone can work on this task!' => 'Cualquiera puede trabajar en esta tarea!',
  'Open Task' => 'Abrir tarea',
  'This task can only be processed by assigned and responsible users.' => 'Esta tarea puede sólo ser procesada por <strong>usuarios asignados y responsables.</strong>',
);
