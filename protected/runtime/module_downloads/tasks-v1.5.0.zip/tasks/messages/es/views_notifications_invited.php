<?php
return array (
  '{userName} assigned you as responsible person in task {task} from space {spaceName}.' => '{userName} te ha asignado como <strong>persona responsable</strong> a cargo de la tarea {task} desde el espacio {spaceName}',
);
