<?php
return array (
  'Already requested' => 'Ya solicitado',
  'Request sent' => 'Solicitud enviada',
  'You have insufficient permissions to perform that operation!' => '¡No tienes suficientes permisos para hacer esa operación!',
);
