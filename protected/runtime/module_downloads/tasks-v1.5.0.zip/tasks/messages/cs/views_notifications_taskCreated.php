<?php
return array (
  '{userName} created a new task {task}.' => '{userName} vytvořil(a) nový úkol {task}.',
);
