<?php
return array (
  'Created by me' => 'Vytvořil(a) jsem',
  'End date' => '',
  'Filter status' => '',
  'Filter tasks' => '',
  'I\'m assigned' => '',
  'I\'m responsible' => '',
  'Overdue' => '',
  'Spaces' => 'prostor(y)',
  'Start date' => '',
  'Status' => 'Stav',
  'Title' => 'Název',
);
