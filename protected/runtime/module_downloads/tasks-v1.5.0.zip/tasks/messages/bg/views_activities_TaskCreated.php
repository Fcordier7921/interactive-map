<?php
return array (
  '{userName} created task {task}.' => '{userName} създаде задача {task}.',
);
