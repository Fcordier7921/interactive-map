<?php
return array (
  'Create' => 'Създай',
);
