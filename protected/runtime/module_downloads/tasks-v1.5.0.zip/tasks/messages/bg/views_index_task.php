<?php
return array (
  'Task Users have been notified' => 'Потребителите, обвързани със задачата, са уведомени',
);
