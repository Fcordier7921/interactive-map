<?php
return array (
  '<b>There are no tasks yet!</b>' => '<b>Все още няма задачи!</b>',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '<b>Все още няма задачи!</b> Бъди първият и създай такава...',
  'Assigned to me' => 'Назначени към мен',
  'Back to stream' => 'Обратно към потока',
  'Created by me' => 'Създадени от мен',
  'Creation time' => 'Време на създаване',
  'Filter' => 'Филтър',
  'Last update' => 'Последна актуализация',
  'No tasks found which matches your current filter(s)!' => 'Не бяха намерени задачи, които да съответстват на текущите ви филтри!',
  'Nobody assigned' => 'Няма никой назначен',
  'Sorting' => 'Подреждане',
  'State is finished' => 'Състоянието е завършено',
  'State is open' => 'Състоянието е отворено',
);
