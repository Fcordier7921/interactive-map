<?php
return array (
  'Drag list' => 'Плъзнете списъка',
);
