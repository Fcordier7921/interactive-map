<?php
return array (
  '<strong>Task</strong> module configuration' => 'Конфигурация на модул на <strong>Задача</strong>',
  'Displays a global task menu item on the main menu.' => 'Показва елемент от менюто на глобалната задача в главното меню.',
  'Global task menu item' => 'Елемент от менюто на глобалната задача',
  'Max tasks items' => 'Макс. брой елементи на задачите',
  'Menu Item sort order' => 'Ред за сортиране на елементи от менюто',
  'Show global task menu item' => 'Показване на елемента от менюто на глобалната задача',
  'Show snippet' => 'Показване на фрагмент',
  'Show snippet in Space' => 'Показване на фрагмент в Раздела',
  'Shows a widget with tasks on the dashboard where you are assigned/responsible.' => 'Показва уиджет със задачи на таблото за управление, където сте назначени/отговорни.',
  'Shows the widget also on the dashboard of spaces.' => 'Показва уиджет и на таблото за управление на разделите.',
  'Sort order' => 'Подреждане',
  'Your tasks snippet' => 'Фрагмент на вашите задачи',
);
