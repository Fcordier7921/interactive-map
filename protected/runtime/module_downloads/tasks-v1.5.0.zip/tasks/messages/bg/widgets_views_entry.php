<?php
return array (
  'Click, to finish this task' => 'Щракнете, за да завършите тази задача',
  'This task is already done. Click to reopen.' => 'Тази задача вече е изпълнена. Щракнете, за да отворите отново.',
);
