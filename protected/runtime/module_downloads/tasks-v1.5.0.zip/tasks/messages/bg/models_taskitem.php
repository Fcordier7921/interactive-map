<?php
return array (
  'Completed' => 'Завършена',
  'Title' => 'Заглавие',
);
