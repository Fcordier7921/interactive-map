<?php
return array (
  'Your Reminder for task {task}' => 'Вашето напомняне за задача {task}',
);
