<?php
return array (
  '1 Day before' => '1 ден преди това',
  '1 Month before' => '1 месец преди това',
  '1 Week before' => '1 седмица преди това',
  '2 Days before' => '2 дена преди това',
  '2 Weeks before' => '2 седмици преди това',
  '3 Weeks before' => '3 седмици преди това',
  'At least 1 Hour before' => 'Поне 1 час преди това',
  'At least 2 Hours before' => 'Поне 2 часа преди това',
  'Do not remind' => 'Не напомняй',
  'Remind Mode' => 'Режим на напомняне',
  'Task' => 'Задача',
);
