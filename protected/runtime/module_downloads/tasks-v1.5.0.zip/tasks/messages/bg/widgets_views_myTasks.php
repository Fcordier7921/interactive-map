<?php
return array (
  '<strong>Your</strong> tasks' => '<strong>Твоите</strong> задачи',
);
