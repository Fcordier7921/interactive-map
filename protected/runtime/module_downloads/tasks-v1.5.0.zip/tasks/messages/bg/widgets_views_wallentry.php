<?php
return array (
  'Anyone can work on this task!' => 'Всеки може да работи по тази задача!',
  'Open Task' => 'Отвори задача',
  'This task can only be processed by assigned and responsible users.' => 'Тази задача може да бъде обработена само от назначени и отговорни потребители.',
);
