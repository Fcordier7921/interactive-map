<?php
return array (
  '{userName} created a new task {task}.' => '{userName} създаде нова задача {task}.',
);
