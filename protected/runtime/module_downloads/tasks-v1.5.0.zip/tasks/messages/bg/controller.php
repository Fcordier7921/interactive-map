<?php
return array (
  'Already requested' => 'Вече е заявена',
  'Request sent' => 'Заявката е изпратена',
  'You have insufficient permissions to perform that operation!' => 'Нямате достатъчно разрешения за извършване на тази операция!',
);
