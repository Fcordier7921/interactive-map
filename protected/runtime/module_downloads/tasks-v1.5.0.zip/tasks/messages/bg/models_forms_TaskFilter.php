<?php
return array (
  'Created by me' => 'Създадени от мен',
  'End date' => 'Крайна дата',
  'Filter status' => 'Състояние на филтъра',
  'Filter tasks' => 'Филтрирайте задачи',
  'I\'m assigned' => 'Аз съм назначен',
  'I\'m responsible' => 'Аз съм отговорен',
  'Overdue' => 'Просрочена',
  'Spaces' => 'Раздели',
  'Start date' => 'Начална дата',
  'Status' => 'Статус',
  'Title' => 'Заглавие',
);
