<?php
return array (
  'Assign users to this task' => 'Назначи потребители за тази задача',
  'Deadline for this task?' => 'Краен срок за тази задача?',
  'Preassign user(s) for this task.' => 'Преназначи потребител(и) за тази задача.',
  'What to do?' => 'Какво да правя?',
);
