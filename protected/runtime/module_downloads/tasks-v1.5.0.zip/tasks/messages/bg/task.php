<?php
return array (
  'Allows the user to create, delete and edit tasks and lists and also sort tasks and lists' => 'Позволява на потребителя да създава, изтрива и редактира задачи и списъци, както и да сортира задачи и списъци',
  'Allows the user to process unassigned tasks' => 'Позволява на потребителя да обработва незададени задачи',
  'Manage tasks' => 'Управление на задачите',
  'Process unassigned tasks' => 'Обработваване на неназначени задачи',
);
