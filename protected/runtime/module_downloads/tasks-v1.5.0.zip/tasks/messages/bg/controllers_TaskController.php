<?php
return array (
  'Could not access task!' => 'Няма достъп до задачата!',
);
