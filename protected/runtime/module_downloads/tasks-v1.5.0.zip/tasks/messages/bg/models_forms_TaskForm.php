<?php
return array (
  'End Date' => 'Крайна дата',
  'End Time' => 'Крайно време',
  'End time must be after start time!' => 'Крайният час трябва да е след началния час!',
  'Public' => 'Публичнa',
  'Start Date' => 'Начална дата',
  'Start Time' => 'Начално време',
  'Time Zone' => 'Часова зона',
);
