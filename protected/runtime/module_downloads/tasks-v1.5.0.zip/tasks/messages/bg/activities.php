<?php
return array (
  '{userName} completed task {task}.' => '{userName} изпълни задача {task}.',
  '{userName} reset task {task}.' => '{userName} нулира задача {task}.',
  '{userName} reviewed task {task}.' => '{userName} прегледа задача {task}.',
  '{userName} works on task {task}.' => '{userName} работи върху задача {task}.',
);
