<?php
return array (
  '{userName} assigned you as responsible person in task {task} from space {spaceName}.' => '{userName} ви назначи като отговорно лице в задача {task} от раздел {spaceName}.',
);
