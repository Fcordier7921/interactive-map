<?php
return array (
  '{userName} assigned to task {task}.' => '{userName} е назначен към задача {task}.',
);
