<?php
return array (
  '<strong>Create</strong> new task' => '<strong>Създаване</strong> на нова задача',
  '<strong>Edit</strong> task' => '<strong>Редактиране</strong> на задача',
  'Assign users' => 'Назначени потребители',
  'Cancel' => 'Отказ',
  'Deadline' => 'Краен срок',
  'Save' => 'Запази',
  'What is to do?' => 'Какво трябва да се направи?',
);
