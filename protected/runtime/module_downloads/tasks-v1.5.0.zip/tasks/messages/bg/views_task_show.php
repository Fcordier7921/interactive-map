<?php
return array (
  '<strong>Confirm</strong> deleting' => '<strong>Потвърди</strong> триенето',
  'Add Task' => 'Добави задача',
  'Cancel' => 'Отказ',
  'Delete' => 'Изтрий',
  'Do you really want to delete this task?' => 'Наистина ли искате да изтриете тази задача?',
  'No open tasks...' => 'Няма отворени задачи...',
  'completed tasks' => 'завършени задачи',
);
