<?php
return array (
  'Create' => 'Opret',
);
