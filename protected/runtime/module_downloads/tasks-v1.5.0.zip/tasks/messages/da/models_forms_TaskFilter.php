<?php
return array (
  'Created by me' => 'Oprettet af mig',
  'End date' => '',
  'Filter status' => '',
  'Filter tasks' => '',
  'I\'m assigned' => '',
  'I\'m responsible' => '',
  'Overdue' => '',
  'Spaces' => 'Sider',
  'Start date' => '',
  'Status' => 'Status',
  'Title' => 'Titel',
);
