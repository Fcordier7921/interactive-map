<?php
return array (
  'End Date' => 'Slut Dato',
  'End Time' => 'Slut tidspunkt',
  'End time must be after start time!' => 'Slut tidspunkt skal være efter start tidspunkt!',
  'Public' => 'Offentlig',
  'Start Date' => 'Start Dato',
  'Start Time' => 'Start Tidspunkt',
  'Time Zone' => 'Tidszone',
);
