<?php
return array (
  '{userName} finished task {task}.' => '{userName} afsluttede opgaven {task}.',
);
