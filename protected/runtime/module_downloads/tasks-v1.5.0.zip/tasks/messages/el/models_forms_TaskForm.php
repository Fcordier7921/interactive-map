<?php
return array (
  'End Date' => 'Ημερομηνία λήξης',
  'End Time' => 'Τέλος χρόνου',
  'End time must be after start time!' => 'Η ώρα λήξης πρέπει να είναι μετά το χρόνο έναρξης!',
  'Public' => 'Δημόσιο',
  'Start Date' => 'Ημερομηνία έναρξης',
  'Start Time' => 'Ωρα έναρξης',
  'Time Zone' => 'Ζώνη ώρας',
);
