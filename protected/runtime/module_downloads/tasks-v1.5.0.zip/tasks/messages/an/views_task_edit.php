<?php
return array (
  '<strong>Create</strong> new task' => '',
  '<strong>Edit</strong> task' => '',
  'Assign users' => '',
  'Cancel' => 'Cancelar',
  'Deadline' => '',
  'Save' => 'Uložit',
  'What is to do?' => '',
);
