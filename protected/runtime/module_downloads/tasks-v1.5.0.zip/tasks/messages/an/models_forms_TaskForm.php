<?php
return array (
  'End Date' => '',
  'End Time' => '',
  'End time must be after start time!' => '',
  'Public' => 'Publico',
  'Start Date' => '',
  'Start Time' => '',
  'Time Zone' => 'Huso horario.',
);
