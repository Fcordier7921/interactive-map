<?php
return array (
  'Created by me' => 'Creyau per yo',
  'End date' => '',
  'Filter status' => '',
  'Filter tasks' => '',
  'I\'m assigned' => '',
  'I\'m responsible' => '',
  'Overdue' => '',
  'Spaces' => 'Espacios',
  'Start date' => '',
  'Status' => '',
  'Title' => 'Titulek',
);
