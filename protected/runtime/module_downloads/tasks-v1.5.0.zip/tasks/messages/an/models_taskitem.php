<?php
return array (
  'Completed' => '',
  'Title' => 'Titulek',
);
