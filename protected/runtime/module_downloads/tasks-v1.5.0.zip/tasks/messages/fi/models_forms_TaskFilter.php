<?php
return array (
  'Created by me' => 'Minun luomat',
  'End date' => 'Päättymispäivä',
  'Filter status' => 'Suodattimen tila',
  'Filter tasks' => 'Suodata tehtävät',
  'I\'m assigned' => 'Minulle määrätyt',
  'I\'m responsible' => 'Joista olen vastuussa',
  'Overdue' => 'Myöhässä',
  'Spaces' => 'Sivut',
  'Start date' => 'Aloituspäivä',
  'Status' => 'Tila',
  'Title' => 'Otsikko',
);
