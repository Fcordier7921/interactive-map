<?php
return array (
  'Already requested' => 'Jo pyydetty',
  'Request sent' => 'Pyyntö lähetetty',
  'You have insufficient permissions to perform that operation!' => 'Sinulla ei ole riittävästi oikeuksia suorittaa tätä toimintoa!',
);
