<?php
return array (
  '1 Day before' => '1 päivä ennen',
  '1 Month before' => '1 kuukausi ennen',
  '1 Week before' => '1 viikko ennen',
  '2 Days before' => '2 päivää ennen',
  '2 Weeks before' => '2 viikkoa ennen',
  '3 Weeks before' => '3 viikkoa ennen',
  'At least 1 Hour before' => 'Vähintään 1 tunti ennen',
  'At least 2 Hours before' => 'Vähintään 2 tuntia ennen',
  'Do not remind' => 'Älä muistuta',
  'Remind Mode' => 'Muistutus',
  'Task' => 'Tehtävä',
);
