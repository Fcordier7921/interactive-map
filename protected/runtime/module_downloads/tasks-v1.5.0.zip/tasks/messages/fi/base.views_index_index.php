<?php
return array (
  'Drag list' => 'Vedä luettelo',
);
