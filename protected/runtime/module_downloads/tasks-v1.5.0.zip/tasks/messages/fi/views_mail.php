<?php
return array (
  'Your Reminder for task {task}' => 'Muistutus tehtävästä {task}',
);
