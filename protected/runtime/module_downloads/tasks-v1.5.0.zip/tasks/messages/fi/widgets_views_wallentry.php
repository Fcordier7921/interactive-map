<?php
return array (
  'Anyone can work on this task!' => 'Jokainen voi työskennellä tämän tehtävän parissa!',
  'Open Task' => 'Avaa tehtävä',
  'This task can only be processed by assigned and responsible users.' => 'Tätä tehtävää voi käsitellä vain määrätyt ja vastuuhenkilöt.',
);
