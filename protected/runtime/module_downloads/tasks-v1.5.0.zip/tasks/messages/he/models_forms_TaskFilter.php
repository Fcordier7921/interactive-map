<?php
return array (
  'Created by me' => '',
  'End date' => '',
  'Filter status' => '',
  'Filter tasks' => '',
  'I\'m assigned' => '',
  'I\'m responsible' => '',
  'Overdue' => '',
  'Spaces' => 'אזורים',
  'Start date' => '',
  'Status' => '',
  'Title' => '',
);
