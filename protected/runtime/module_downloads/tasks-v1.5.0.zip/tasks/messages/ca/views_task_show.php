<?php
return array (
  '<strong>Confirm</strong> deleting' => '',
  'Add Task' => '',
  'Cancel' => 'Cancel·la',
  'Delete' => 'Suprimeix',
  'Do you really want to delete this task?' => '',
  'No open tasks...' => '',
  'completed tasks' => '',
);
