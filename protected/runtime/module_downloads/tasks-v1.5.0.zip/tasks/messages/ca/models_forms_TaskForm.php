<?php
return array (
  'End Date' => 'Data final',
  'End Time' => 'Hora de finalització',
  'End time must be after start time!' => 'L\'hora final ha de ser després de l\'hora d\'inici!',
  'Public' => 'Públic',
  'Start Date' => 'Data d\'inici',
  'Start Time' => 'Hora d\'inici',
  'Time Zone' => 'Fus horari',
);
