<?php
return array (
  '<strong>Task</strong> module configuration' => 'Paramétrage du module <strong>Tâches</strong>',
  'Displays a global task menu item on the main menu.' => 'Affiche un élément du menu de tâches global dans le menu principal.',
  'Global task menu item' => 'Élément du menu de tâches global',
  'Max tasks items' => 'Masquer les éléments de tâche',
  'Menu Item sort order' => 'Ordre de tri des éléments du menu',
  'Show global task menu item' => 'Montrer l\'élément du menu de tâches global',
  'Show snippet' => 'Afficher un extrait',
  'Show snippet in Space' => 'Afficher un extrait dans l\'espace',
  'Shows a widget with tasks on the dashboard where you are assigned/responsible.' => 'Afficher dans le fil d\'actualités un widget avec les tâches sur lesquelles vous êtes affecté ou dont vous êtes responsable.',
  'Shows the widget also on the dashboard of spaces.' => 'Affiche le widget également sur le tableau de bord des espaces.',
  'Sort order' => 'Ordre de tri',
  'Your tasks snippet' => 'Extrait de vos tâches',
);
