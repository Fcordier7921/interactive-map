<?php
return array (
  '<strong>Create</strong> new task' => '<strong>Créer</strong> une nouvelle tâche',
  '<strong>Edit</strong> task' => '<strong>Modifier</strong> une tâche',
  'Assign users' => 'Affecter des utilisateurs',
  'Cancel' => 'Annuler',
  'Deadline' => 'Échéance',
  'Save' => 'Enregistrer',
  'What is to do?' => 'Qu\'est-ce qu\'il y a à faire ?',
);
