<?php
return array (
  '1 Day before' => '1 jour avant',
  '1 Month before' => '1 mois avant',
  '1 Week before' => '1 semaine avant',
  '2 Days before' => '2 jours avant',
  '2 Weeks before' => '2 semaines avant',
  '3 Weeks before' => '3 semaines avant',
  'At least 1 Hour before' => 'Au moins 1 heure avant',
  'At least 2 Hours before' => 'Au moins 2 heures avant',
  'Do not remind' => 'Ne pas rappeller',
  'Remind Mode' => 'Mode de rappel',
  'Task' => 'Tâche',
);
