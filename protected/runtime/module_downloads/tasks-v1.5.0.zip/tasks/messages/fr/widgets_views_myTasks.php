<?php
return array (
  '<strong>Your</strong> tasks' => 'Mes <strong>tâches</strong>',
);
