<?php
return array (
  'End Date' => 'Date de fin',
  'End Time' => 'Heure de fin',
  'End time must be after start time!' => 'L\'heure de fin doit être après l\'heure de départ.',
  'Public' => 'Public',
  'Start Date' => 'Date de départ',
  'Start Time' => 'Heure de départ',
  'Time Zone' => 'Fuseau horaire',
);
