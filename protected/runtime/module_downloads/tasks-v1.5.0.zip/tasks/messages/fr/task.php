<?php
return array (
  'Allows the user to create, delete and edit tasks and lists and also sort tasks and lists' => 'Autoriser l\'utilisateur à créer, modifier, trier et supprimer des tâches et des listes',
  'Allows the user to process unassigned tasks' => 'Autoriser l\'utilisateur à traiter les tâches non affectées',
  'Manage tasks' => 'Gérer les tâches',
  'Process unassigned tasks' => 'Traiter les tâches non affectées',
);
