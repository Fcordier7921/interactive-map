<?php
return array (
  'Anyone can work on this task!' => 'Tout le monde peut travailler à cette tâche !',
  'Open Task' => 'Ouvrir la tâche',
  'This task can only be processed by assigned and responsible users.' => 'Cette tâche ne peut être traitée que par les personnes affectées à celle-ci ou par les responsables de la tâche.',
);
