<?php
return array (
  'Task Users have been notified' => 'Les utilisateurs de la tâche ont été prévenus',
);
