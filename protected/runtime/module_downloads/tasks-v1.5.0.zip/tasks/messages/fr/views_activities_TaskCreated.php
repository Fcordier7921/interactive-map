<?php
return array (
  '{userName} created task {task}.' => '{userName} a créé la tâche {task}.',
);
