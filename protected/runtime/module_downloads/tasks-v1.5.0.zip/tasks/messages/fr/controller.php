<?php
return array (
  'Already requested' => 'Déjà demandée',
  'Request sent' => 'Demande envoyée',
  'You have insufficient permissions to perform that operation!' => 'Vous n\'avez pas les permissions suffisantes pour effectuer cette opération !',
);
