<?php
return array (
  '{userName} assigned you as responsible person in task {task} from space {spaceName}.' => '{userName} vous a nommé responsable de la tâche {task} dans l\'espace {spaceName}.',
);
