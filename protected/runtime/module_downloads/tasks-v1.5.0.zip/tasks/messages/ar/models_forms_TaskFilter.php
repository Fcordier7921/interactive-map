<?php
return array (
  'Created by me' => 'التي كتبتها أنا',
  'End date' => '',
  'Filter status' => '',
  'Filter tasks' => '',
  'I\'m assigned' => '',
  'I\'m responsible' => '',
  'Overdue' => '',
  'Spaces' => 'الباحات',
  'Start date' => '',
  'Status' => 'الحالة',
  'Title' => 'العنوان',
);
