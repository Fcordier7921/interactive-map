<?php
return array (
  'Completed' => '',
  'Title' => 'العنوان',
);
