<?php
return array (
  'End Date' => '',
  'End Time' => '',
  'End time must be after start time!' => '',
  'Public' => 'عام',
  'Start Date' => '',
  'Start Time' => '',
  'Time Zone' => '',
);
