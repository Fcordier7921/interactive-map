<?php

return [
    'Completed' => '',
    'Title' => '',
];
