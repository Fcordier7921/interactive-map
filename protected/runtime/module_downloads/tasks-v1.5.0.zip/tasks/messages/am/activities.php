<?php

return [
    '{userName} completed task {task}.' => '',
    '{userName} reset task {task}.' => '',
    '{userName} reviewed task {task}.' => '',
    '{userName} works on task {task}.' => '',
];
