<?php
return array (
  'End Date' => '',
  'End Time' => '',
  'End time must be after start time!' => '',
  'Public' => 'የህዝብ',
  'Start Date' => '',
  'Start Time' => '',
  'Time Zone' => 'የጊዜ ቀጠና',
);
