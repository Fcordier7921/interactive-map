<?php
return array (
  '{userName} completed task {task}.' => '{userName} کار {task} را کامل کرد.',
  '{userName} reset task {task}.' => '{userName} کار {task} را بازنشانی کرد.',
  '{userName} reviewed task {task}.' => '{userName} کار {task} را بازبینی کرد.',
  '{userName} works on task {task}.' => '{userName} بر روی {task} کار می‌کند.',
);
