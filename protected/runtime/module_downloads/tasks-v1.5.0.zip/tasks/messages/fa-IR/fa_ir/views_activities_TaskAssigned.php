<?php
return array (
  '{userName} assigned to task {task}.' => '{userName} موظف به انجام کار {task} شد.',
);
