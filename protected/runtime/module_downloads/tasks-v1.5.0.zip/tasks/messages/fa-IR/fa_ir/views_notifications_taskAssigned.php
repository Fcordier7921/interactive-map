<?php
return array (
  '{userName} assigned you to the task {task}.' => 'کار {task} به {userName} سپرده‌شد.',
);
