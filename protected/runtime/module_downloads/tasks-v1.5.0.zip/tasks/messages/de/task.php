<?php
return array (
  'Allows the user to create, delete and edit tasks and lists and also sort tasks and lists' => 'Erlaubt dem Benutzer die Erstellung, Löschung, Bearbeitung sowie Sortierung von Aufgaben und Listen',
  'Allows the user to process unassigned tasks' => 'Erlaubt dem Benutzer das Bearbeiten nicht zugewiesener Aufgaben',
  'Manage tasks' => 'Aufgaben verwalten',
  'Process unassigned tasks' => 'Bearbeiten nicht zugewiesener Aufgaben',
);
