<?php
return array (
  'Assignment' => 'Zuweisung',
  'Could not access task!' => 'Zugriff auf Aufgabe nicht möglich!',
);
