<?php
return array (
  'Assignment' => 'Zuweisung',
  '{userName} assigned to task {task}.' => '{userName} wurde Aufgabe »{task}« zugewiesen.',
);
