<?php
return array (
  'Drag list' => 'Liste verschieben',
);
