<?php
return array (
  '{userName} created a new task {task}.' => ' {userName} hat die Aufgabe »{task}« erstellt.',
);
