<?php
return array (
  '<strong>Your</strong> tasks' => '<strong>Deine</strong> Aufgaben',
);
