<?php
return array (
  'Click, to finish this task' => 'Klicke, um die Aufgabe zu beenden.',
  'This task is already done. Click to reopen.' => 'Diese Aufgabe ist bereits abgeschlossen. Klicke, um sie wieder zu aktivieren.',
    'Assignment' => 'Zuweisung',


);
